<?php
/**
 * Класс для работы с LinkEnso
 *
 * @link https://lazydev.pro/
 * @author LazyDev <email@lazydev.pro>
 **/

namespace LazyDev;

class LinkEnso
{
	private static $instance = null;
	static $sqlWhere = [];
	static $modCfg;
	
	/**
     * Конструктор
     *
	 * @return   LinkEnso
     */
	static function construct()
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }

        return self::$instance;
    }
	
	/**
     * Старт модуля
     *
     * @param    array    $linkEnsoConfig
	 * @return   LinkEnso
     */
    static function load($linkEnsoConfig)
    {
		global $config, $db, $row;
		
		self::$modCfg = $linkEnsoConfig;
		
		// Поддержка новых версий MySQL
		$oldMySQL = version_compare($db->mysql_version, '5.5.3', '<') == 1 ? false : true;
		
		// Не брать текущую новость
		self::$sqlWhere['where'][] = 'id != ' . self::$modCfg['newsId'];
		
		$postCategories = explode(',', $row['category']);
		$categoriesArray = [];
		switch (self::$modCfg['scan']) {
			// Если нужно сканировать только текущую категорию
			case 'same':
				// Каждую категорию текущего поста и все ее подкатегории добавляем в общий массив
				foreach ($postCategories as $postCategory) {
					$postCategory = intval($postCategory);
					$categoriesArray[] = $postCategory;
					$categoriesArray = array_merge($categoriesArray, self::getSubcategoriesArray($postCategory));
				}
				break;

			// Если нужно сканировать глобальную категорию
			case 'global':
				// Для каждой из категорий текущего поста находим корневую категорию и все её подкатегории
				foreach ($postCategories as $postCategory) {
					$postCategory = intval($postCategory);
					$globalCategoryId = self::getGlobalCategory($postCategory);
					$categoriesArray[] = $globalCategoryId;
					$categoriesArray = array_merge($categoriesArray, self::getSubcategoriesArray($globalCategoryId));
				}
				break;
		}
		
		// Работа с категориями
		self::$sqlWhere['cat'] = '';
		if ($categoriesArray) {
			$categoriesArray = array_unique($categoriesArray);
			// Поддержка DataLife Engine 13.2
			if ($config['version_id'] > 13.1) {
				self::$sqlWhere['cat'] = "INNER JOIN (SELECT DISTINCT(" . PREFIX . "_post_extras_cats.news_id) FROM " . PREFIX . "_post_extras_cats WHERE cat_id IN (" . implode(',', $categoriesArray) . ")) c ON (p.id=c.news_id)";
			} else {
				if ($config['allow_multi_category']) {
					if ($oldMySQL) {
						self::$sqlWhere['where'][] = "category REGEXP '[[:<:]](" . implode ('|', $categoriesArray)  . ")[[:>:]]'";
					} else {
						// Поддержка MySQL 8.0+
						self::$sqlWhere['where'][] = "category REGEXP '([[:punct:]]|^)(" . implode ('|', $categoriesArray) . ")([[:punct:]]|$)'";
					}
				} else {
					self::$sqlWhere['where'][] = "category IN ('" . implode("','", $categoriesArray). "')";
				}
			}
		}

		self::$sqlWhere['id'] = 'id' . (self::$modCfg['date'] == 'new' ? ' > ' : ' < ') . self::$modCfg['newsId'];
		
		// Стандартные данные DLE
		if ($config['no_date'] && !$config['news_future']) {
			self::$sqlWhere['where'][] = "date < '" . date ('Y-m-d H:i:s', time()) . "'";
		}
		
		return self::$instance;
    }
	
	/**
     * Возвращает массив данных о SQL запросе
     *
	 * @return   array
     */
	static function sql()
	{
		global $db;
		
		$getCount = [];
		$whereFirst = implode(' AND ', self::$sqlWhere['where']);
		
		// Если включена опция закольцевать ссылки
		if (self::$modCfg['link']) {
			$getId = $db->super_query("SELECT p.id FROM " . PREFIX . "_post p " . self::$sqlWhere['cat'] . " LEFT JOIN " . PREFIX . "_post_extras e ON (p.id=e.news_id) WHERE approve AND {$whereFirst} AND " . self::$sqlWhere['id'], true);
		}
		
		$sqlSelect = "p.id, p.autor, p.date, p.short_story, CHAR_LENGTH(p.full_story) as full_story, p.xfields, p.title, p.category, p.alt_name, p.comm_num, p.allow_comm, p.fixed, p.tags, e.news_read, e.allow_rate, e.rating, e.vote_num, e.votes, e.view_edit, e.editdate, e.editor, e.reason FROM " . PREFIX . "_post p " . self::$sqlWhere['cat'] . " LEFT JOIN " . PREFIX . "_post_extras e ON (p.id=e.news_id)";
		$order = self::$modCfg['date'] == 'new' ? 'ASC' : 'DESC';
		
		// Если включена опция закольцевать ссылки
		if (count($getId) < self::$modCfg['news'] && self::$modCfg['link']) {
			$excludeId = [];
			foreach ($getId as $post) {
				$excludeId[] = $post['id'];
			}
			
			// Исключаем новости с второго запроса и оптимизируем первый
			if ($excludeId) {
				self::$sqlWhere['where'][] = 'p.id NOT IN(' . implode(',', $excludeId) . ')';
				$setId = 'p.id IN(' . implode(',', $excludeId) . ')';
			}
			$whereSecond = implode(' AND ', self::$sqlWhere['where']);
			
			$firstLimit = count($getId);
			$secondLimit = self::$modCfg['news'] - count($getId);
			
			// Если это не первая или последняя новость в зависимости от опции какие новости показывать
			if ($firstLimit > 0) {
				return "SELECT * FROM ((SELECT {$sqlSelect} WHERE approve AND {$setId} ORDER BY id {$order}) UNION (SELECT {$sqlSelect} WHERE approve AND {$whereSecond} ORDER BY id {$order} LIMIT {$secondLimit})) as l";
			} else {
				return "SELECT {$sqlSelect} WHERE approve AND {$whereSecond} ORDER BY id {$order} LIMIT " . self::$modCfg['news'];
			}
		} else {
			return "SELECT {$sqlSelect} WHERE approve AND {$whereFirst} AND " . self::$sqlWhere['id'] . " ORDER BY id {$order} LIMIT " . self::$modCfg['news'];
		}

	}
	
	/**
     * Метод рекурсивно возвращает массив всех подкатегорий определенной категории
     *
     * @param    int    $categoryId
	 * @return   array
     */
	static function getSubcategoriesArray($categoryId)
	{
		global $cat_info;
		
		// Массив со списком подкатегорий
		$subcategoriesArray = [];

		foreach ($cat_info as $cat) {
			if ($cat['parentid'] == $categoryId) {
				// Добавляем в массив подкатегорию
				$subcategoriesArray[] = intval($cat['id']);

				// Добавляем в массив все ее подкатегории
				$subcategoriesArray = array_merge($subcategoriesArray, self::getSubcategoriesArray($cat['id']));
			}
		}

		// Возвращаем массив подкатегорий
		return $subcategoriesArray;
	}
	 
	/**
     * Метод возвращает родительскую категорию
     *
     * @param    int    $categoryId
	 * @return   int
     */
	static function getGlobalCategory($categoryId)
	{
		global $cat_info;

		// Получаем самую корневую категорию
		while ($cat_info[$categoryId]['parentid'] > 0) {
			$categoryId = intval($cat_info[$categoryId]['parentid']);
		}

		// Возвращаем самую главную родительскую категорию
		return $categoryId;
	}
}