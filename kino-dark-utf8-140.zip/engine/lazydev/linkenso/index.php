<?php
/**
* Информация о старом модуле
*
* @link_author https://alaev.info/blog/post/3982
* @author Фомин Александр Алексеевич <mail@mithrandir.ru>
*
* @helper ПафНутиЙ <pafnuty10@gmail.com>
* @link_helper https://pafnuty.name/
*
* Информация о новом модуле
*
* @link https://lazydev.pro/
* @author LazyDev <email@lazydev.pro>
**/

include_once __DIR__ . '/loader.php';
include_once __DIR__ . '/linkenso.class.php';

// Массив настроек подключения модуля
$linkEnsoConfig = [
	'newsId'   => !empty($newsId) ? intval($newsId) : false,
	'news'     => !empty($news) ? intval($news) : 5,
	'date'     => !empty($date) ? strip_tags(stripslashes($date)) : 'old',
	'link'     => !empty($link) ? intval($link) : 1,
	'scan'     => !empty($scan) ? strip_tags(stripslashes($scan)) : 'all',
	'template' => !empty($template) ? strip_tags(stripslashes($template)) : 'linkenso'
];

// Проверка на существование пользовательского файла
if (!file_exists(TEMPLATE_DIR . '/lazydev/linkenso/' . $linkEnsoConfig['template'] . '.tpl')) {
	$linkEnsoConfig['template'] = 'linkenso';
}

// Если что-то пошло не так
if (!$linkEnsoConfig['newsId']) {
	return;
}

// Чтение кэша
$cacheHash = md5(implode('_', $linkEnsoConfig)) . $config['skin'];
$output = dle_cache('linkenso', $cacheHash);
if ($output !== false) {
	echo $output;
	return;
}

// Вызов класса модуля
$sqlSelect = LazyDev\LinkEnso::construct()->load($linkEnsoConfig)->sql();

// Подключение стандартного функционала DataLife Engine
$sql_result = $db->query($sqlSelect);
$tpl->load_template('lazydev/linkenso/' . $linkEnsoConfig['template'] . '.tpl');
include (DLEPlugins::Check(ENGINE_DIR . '/modules/show.custom.php'));
if ($config['files_allow'] && strpos($tpl->result['content'], '[attachment=') !== false) {
	$tpl->result['content'] = show_attach($tpl->result['content'], $attachments);
}

$tpl->load_template('lazydev/linkenso/block.tpl');
if (trim($tpl->result['content']) != '') {
	$tpl->set('{linkenso}', $tpl->result['content']);
	$tpl->set_block("'\\[linkenso\\](.*?)\\[/linkenso\\]'si", '\\1');
	$tpl->set_block("'\\[not-linkenso\\](.*?)\\[/not-linkenso\\]'si", '');
} else {
	$tpl->set('{linkenso}', '');
	$tpl->set_block("'\\[linkenso\\](.*?)\\[/linkenso\\]'si", '');
	$tpl->set_block("'\\[not-linkenso\\](.*?)\\[/not-linkenso\\]'si", '\\1');
}
$tpl->compile('linkenso');
$tpl->clear();

// Запись кэша
create_cache('linkenso', $tpl->result['linkenso'], $cacheHash);

echo $tpl->result['linkenso'];