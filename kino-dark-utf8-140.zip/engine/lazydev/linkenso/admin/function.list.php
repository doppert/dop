<?php
/**
* Функции для работы с админ панелью
*
* @link https://lazydev.pro/
* @author LazyDev <email@lazydev.pro>
**/

/**
 * Данные таблицы
 *
 * @param    string    $title
 * @param    string    $description
 * @param    string    $field
 * @param	 string	   $helper
 **/
function lazyRow($title = '', $description = '', $field = '', $helper = '')
{
	$description = $description ? '<span class="text-muted text-size-small hidden-xs">' . $description . '</span>' : '';
	$helper = $helper ? '<i class="help-button visible-lg-inline-block text-primary-600 fa fa-question-circle position-right" data-rel="popover" data-trigger="hover" data-placement="right" data-html="true" data-content="' . $helper . '" data-original-title="" title=""></i>' : '';
	echo '<tr>
		<td class="col-xs-6 col-sm-6 col-md-7">
			<h6 class="media-heading text-semibold">' . $title .  $helper . '</h6>
			' . $description . '
		</td>
		<td class="col-xs-6 col-sm-6 col-md-5">' . $field . '</td>
	</tr>';
}

/**
 * Параметры input
 *
 * @param    array    $data
 * @return   string
 **/
function lazyInput($data)
{
	$inputElemet = $data[3] ? ' placeholder="' . $data[3] . '"' : '';
	$inputElemet .= $data[4] ? ' disabled' : '';
	if ($data[1] == 'number') {
		$inputElemet .= $data[5] ? ' min="' . $data[5] . '"' : '';
		$inputElemet .= $data[6] ? ' max="' . $data[6] . '"' : '';
	}
	return '<input type="' . $data[1] . '" autocomplete="off" style="float: right;" value="' . $data[2]. '" class="form-control" name="' . $data[0] . '" ' . $inputElemet . '>';
}

/**
 * Параметры checkbox
 *
 * @param    string    $name
 * @param    bool      $checked
 * @param    string    $id
 * @return   string
 **/
function lazyCheckBox($name, $checked, $id)
{
	$checkedArray = $checked ? ['checked', 'on'] : ['', ''];

	return '<input class="checkBox" type="checkbox" id="' . $id . '" name="' . $name . '" value="1" ' . $checkedArray[0] . '>
	<div class="br-toggle br-toggle-success ' . $checkedArray[1] . '" data-id="' . $id . '">
		<div class="br-toggle-switch"></div>
	</div>';
}

/**
 * Параметры select
 *
 * @param    array    $data
 * @return   string
 **/
function lazySelect($data)
{
	$output = '';
	foreach ($data[1] as $key => $val) {
		if ($data[2]) {
			$output .= "<option value=\"{$key}\"";
		} else {
			$output .= "<option value=\"{$val}\"";
		}
		
		if (is_array($data[3])) {
			foreach ($data[3] as $element) {
				if ($data[2] && $element == $key) {
					$output .= ' selected ';
				} elseif (!$data[2] && $element == $val) {
					$output .= ' selected ';
				}
			}
		} elseif ($data[2] && $data[3] == $key) {
			$output .= ' selected ';
		} elseif (!$data[2] && $data[3] == $val) {
			$output .= ' selected ';
		}
		
		$output .= ">{$val}</option>\n";
	}
	$inputElemet = $data[5] ? ' disabled' : '';
	$inputElemet .= $data[4] ? ' multiple' : '';
	$inputElemet .= $data[6] ? " data-placeholder=\"{$data[6]}\"" : '';

	return '<select name="' . $data[0] . '" class="form-control custom-select chosen" ' . $inputElemet . '>' . $output . '</select>';
}