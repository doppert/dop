<?php
/**
* Генерация подключения модуля
*
* @link https://lazydev.pro/
* @author LazyDev <email@lazydev.pro>
**/

include __DIR__ . '/function.list.php';

$dateNews = [
	'old' => $langVar['admin']['generate']['date_old'],
	'new' => $langVar['admin']['generate']['date_new']
];
$catNews = [
	'all' => $langVar['admin']['generate']['all'],
	'same' => $langVar['admin']['generate']['same'],
	'global' => $langVar['admin']['generate']['global']
];
echo <<<HTML
<form id="formGenerate">
    <div class="panel panel-flat">
			<div class="panel-body" style="font-size:15px; font-weight:bold;">{$langVar['admin']['head_main']}</div>
			<div class="table-responsive">
				<table class="table">
HTML;
lazyRow(
	$langVar['admin']['generate']['template'],
    $langVar['admin']['generate']['template_descr'],
    lazyInput(['template', 'text', '']),
	$langVar['admin']['generate']['template_info']
);
lazyRow(
	$langVar['admin']['generate']['news'],
    $langVar['admin']['generate']['news_descr'],
    lazyInput(['news', 'number', 5, false, false, 3, 99])
);
lazyRow(
	$langVar['admin']['generate']['date'],
    $langVar['admin']['generate']['date_descr'],
    lazySelect(['date', $dateNews, true, false, false, false])
);
lazyRow(
	$langVar['admin']['generate']['link'],
    $langVar['admin']['generate']['link_descr'],
    lazyCheckBox('link', false, 'link')
);
lazyRow(
	$langVar['admin']['generate']['scan'],
    $langVar['admin']['generate']['scan_descr'],
    lazySelect(['scan', $catNews, true, false, false, false])
);
lazyRow(
	$langVar['admin']['generate']['generate'],
    '',
    '<textarea style="min-height:150px;resize: none;max-height:150px;min-width:333px;max-width:100%;border:1px solid #ddd;padding:5px;" autocomplete="off" class="form-control" id="generate" readonly>{include file="engine/lazydev/linkenso/index.php?newsId={news-id}"}</textarea>'
);
echo <<<HTML
			</table>
		</div>
    </div>
</form>
HTML;

$jsAdminScript[] = <<<HTML

$(function() {
    $('body').on('change', '#formGenerate', function(e) {
		let stringInclude = '{include file="engine/lazydev/linkenso/index.php?newsId={news-id}';
		let formArray = $('#formGenerate').serializeArray();
		$.each(formArray, function(index, value) {
			value.value = value.value.trim();
			if (value.value != '') {
				stringInclude += '&' + value.name + '=' + value.value;
			}
		});
		stringInclude += '"}';
		$('#generate').val(stringInclude);
    });
});
HTML;

?>