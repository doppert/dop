<?php
/**
* Админ панель
*
* @link https://lazydev.pro/
* @author LazyDev <email@lazydev.pro>
**/

if (!defined('DATALIFEENGINE') || !defined('LOGGED_IN')) {
	header('HTTP/1.1 403 Forbidden');
	header('Location: ../../');
	die('Hacking attempt!');
}

include realpath(__DIR__ . '/..') . '/loader.php';

$jsAdminScript = [];
$additionalJsAdminScript = [];

$speedbar = '<li><i class="fa fa-home position-left"></i>' . $langVar['admin']['speedbar_main'] . '</li>';

include ENGINE_DIR . '/lazydev/' . $modLName . '/admin/template/main.php';
include ENGINE_DIR . '/lazydev/' . $modLName . '/admin/generate.php';
include ENGINE_DIR . '/lazydev/' . $modLName . '/admin/template/footer.php';

?>