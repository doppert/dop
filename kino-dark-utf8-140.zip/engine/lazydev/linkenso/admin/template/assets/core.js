'use strict';

class Admin {
    constructor(name) {
        this.mod = name;

        $('select.chosen').chosen({allow_single_deselect: true, no_results_text: 'Ничего не найдено', width: '300px'});
        
        $('body').on('click', '.br-toggle', function() {
            let toogleId = $(this).data('id');
            if ($('#' + toogleId).prop('checked')) {
                $(this).removeClass('on');
                $('#' + toogleId).prop('checked', false);
            } else {
                $(this).addClass('on');
                $('#' + toogleId).prop('checked', 'checked');
            }
			$('form').trigger('change');
        });
    }
}