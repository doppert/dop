<?php
@error_reporting ( E_ALL ^ E_WARNING ^ E_NOTICE );
@ini_set ( 'display_errors', true );
@ini_set ( 'html_errors', false );
@ini_set ( 'error_reporting', E_ALL ^ E_WARNING ^ E_NOTICE );

define( 'DATALIFEENGINE', true );
define( 'ROOT_DIR', substr( dirname(  __FILE__ ), 0, -12 ) );
define( 'ENGINE_DIR', ROOT_DIR . '/engine' );

include ENGINE_DIR . '/classes/plugins.class.php';
include ENGINE_DIR . '/data/config.php';
require_once ENGINE_DIR . '/classes/mysql.php';
require_once ENGINE_DIR . '/data/dbconfig.php';
require_once ENGINE_DIR . '/modules/functions.php';
require_once ENGINE_DIR . '/classes/templates.class.php';
require_once ENGINE_DIR . '/mods/favorites/loader.php';
require_once ENGINE_DIR . '/mods/favorites/class.favorites.php';


require_once ENGINE_DIR . '/modules/sitelogin.php';
require_once ROOT_DIR . '/language/' . $config['langs'] . '/website.lng';
@header( "Content-type: text/html; charset=" . $config['charset'] );

if(!$is_logged) $member_id['user_group'] = 5;

//################# Определение групп пользователей
$user_group = get_vars( "usergroup" );
if( ! $user_group ) {
    $user_group = array ();
    $db->query( "SELECT * FROM " . USERPREFIX . "_usergroups ORDER BY id ASC" );
    while ( $row = $db->get_row() ) {
        $user_group[$row['id']] = array ();
        foreach ( $row as $key => $value ) $user_group[$row['id']][$key] = stripslashes($value);
    }
    set_vars( "usergroup", $user_group );
    $db->free();
}
//################# Определение категорий и их параметры
$cat_info = get_vars( "category" );
if( ! is_array( $cat_info ) ) {
    $cat_info = array ();
    $db->query( "SELECT * FROM " . PREFIX . "_category ORDER BY posi ASC" );
    while ( $row = $db->get_row() ) {
        $cat_info[$row['id']] = array ();
        foreach ( $row as $key => $value ) $cat_info[$row['id']][$key] = stripslashes( $value );
    }
    set_vars( "category", $cat_info );
    $db->free();
}
define( 'TEMPLATE_DIR', ROOT_DIR . '/templates/'.$config['skin']);
$custom = isset($_POST["castom"]) && is_scalar($_POST["castom"]) ? trim(strip_tags(stripslashes($_POST["castom"]))) : false;
if($custom==false) return;
if( strpos( $custom, "custom" ) !== false ) {
    $custom = "{".$custom."}";
    $custom = preg_replace_callback( "#\\{custom(.+?)\\}#i", "custom_print", $custom );

    $favmod = new Sandev\Favorites;

    if($custom !="") {
       $favmod->setContent($custom);
    } echo $custom;

}
?>