<?PHP 

//Mymod_notion Configurations

$NtCnfg = array (
'user_id' => '',
'days' => '1000',
'limit' => '5',
'title_in' => '0',
'xfield' => '',
'reason_in' => '1',
'reason_xfield' => 'reasonedit',
'upd_notsee' => '1',
'cat_on' => '0',
'notcat' => '',
);

?>