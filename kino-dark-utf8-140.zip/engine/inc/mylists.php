<?php

/*
=====================================================
 Файл: mylists.php
-----------------------------------------------------
 Назначение: Настройки модуля «Мои списки»
=====================================================
*/

if( !defined( 'DATALIFEENGINE' ) OR !defined( 'LOGGED_IN' ) ) {
	die( "Hacking attempt!" );
}

$__name = "Мои списки v2.3 от 09.06.2018";
$__descr = "Закладки для пользователей и гостей";

if ( $action ) {

	if( !$user_group[$member_id['user_group']]['admin_addnews'] ) {
		die( '{"success":false,"message":"' . $lang['index_denied'] . '"}' );
	}

	if ( $action == "config" ) {

		$config_mod = is_array( $_POST['config'] ) ? $_POST['config'] : array();

		if ( !$config_mod['options'] ) {
			$config_mod['options'] = "1|Любимые сериалы|likeserials";
		}

		$options = array();

		foreach ( explode( "\n", $config_mod['options'] ) as $option ) {
			$option = explode( "|", trim( $option ) );

			if ( is_numeric( $option[0] ) && strlen( $option[1] ) > 0 ) {
				$option[0] = intval( $option[0] );
				$option[1] = $db->safesql( trim( strip_tags( $option[1] ) ) );
			} else {
				continue;
			}

			if ( !$option[2] ) {
				$option[2] = totranslit( stripslashes( $option[1] ), true, false );
			}

			$options[$option[0]] = array( $option[1], $option[2] );
		}

		$config_mod['options'] = $options;

		if ( !$config_mod['template'] ) {
			$config_mod['template'] = "shortstory.tpl";
		}

		file_put_contents( ENGINE_DIR . '/data/config.' . $mod . '.json', json_encode( $config_mod ) );

		die( '{"success":true,"message":"Настройки успешно сохранены"}' );

	}

	if( $action == "sections" ) {

		$row = $db->super_query( "SELECT id, name FROM " . PREFIX . "_admin_sections WHERE name = '{$mod}'" );

		if ( $row ) {

			$db->query("DELETE FROM " . PREFIX . "_admin_sections WHERE name = '{$mod}'");

			die( '{"success":true,"message":"Модуль убран из меню «Сторонние модули»"}' );

		} else {

			$db->query( "INSERT IGNORE INTO " . PREFIX . "_admin_sections (name, title, descr, icon, allow_groups) VALUES ('{$mod}', '{$__name}', '{$descr}', '', '1')" );

			die( '{"success":true,"message":"Модуль добавлен в меню «Сторонние модули»"}' );

		}

	}
}

if( !$user_group[$member_id['user_group']]['admin_addnews'] ) {
	msg( "error", $lang['index_denied'], $lang['index_denied'] );
}

$config_mod = json_decode( file_get_contents( ENGINE_DIR . '/data/config.' . $mod . '.json' ), true );
if ( !$config_mod ) $config_mod = array();

$buffer = "";

foreach ( array( 'h1' => 'Заголовок H1', 'title' => 'Метатег Title', 'description' => 'Метатег Description', 'keywords' => 'Метатег Keywords' ) as $name => $title ) {

	$buffer .= "<tr><td class=\"col-xs-6 col-sm-6 col-md-7 white-line\"><h6 class=\"media-heading text-semibold\">{$title}</h6><span><b>[list]</b> выбран список {list} <b>[/list]</b> <br><b>[not-list]</b>все новости из списков<b>[/not-list]</b></span></td><td class=\"col-xs-6 col-sm-6 col-md-7 white-line\"><input name=\"config[metatags][{$name}]\" class=\"form-control\" value=\"" . ( isset( $config_mod['metatags'][$name] ) ? $config_mod['metatags'][$name] : "Мои списки[list] » {list}[/list]" ) . "\"></td></tr>";

}

$options = array();

foreach ( $config_mod['options'] as $id => $option ) {
	$options[] = "{$id}|{$option['0']}|{$option['1']}";
}

if ( count( $options ) ) {
	$options = implode( "\n", $options );
} else {
	$options = "1|Любимые сериалы|likeserials";
}

$buffer.= "<tr><td class=\"col-xs-6 col-sm-6 col-md-7 white-line\"><h6 class=\"media-heading text-semibold\">Список разделов</h6><span>Укажите список разделов в нужном порядке каждый с новой строчки в следующем формате: <b>номер|название|url</b>. К примеру: <b>1|Любимые сериалы|likeserials</b>. Если url раздела вы не укажете, то он пропишется автоматически.</span></td><td class=\"col-xs-6 col-sm-6 col-md-7 white-line\"><textarea name=\"config[options]\" style=\"height: 100px\" class=\"form-control\">{$options}</textarea></td></tr>";

$buffer.= "<tr><td class=\"col-xs-6 col-sm-6 col-md-7 white-line\"><h6 class=\"media-heading text-semibold\">Текст-заглушка</h6><span>Данный текст будет выведет пользователю, если в текущем списке нет новостей.</span></td><td class=\"col-xs-6 col-sm-6 col-md-7 white-line\"><textarea name=\"config[not_found]\" style=\"height: 100px\" class=\"form-control\">{$config_mod['not_found']}</textarea></td></tr>";

$buffer .= "<tr><td class=\"col-xs-6 col-sm-6 col-md-7 white-line\"><h6 class=\"media-heading text-semibold\">Шаблон новостей</h6><span>По умолчанию для вывода списка новостей в модуле используется стандарный shortstory.tpl, но вы можете указать свой шаблон, если потребуется</span></td><td class=\"col-xs-6 col-sm-6 col-md-7 white-line\"><input name=\"config[template]\" class=\"form-control\" value=\"" . ( isset( $config_mod['template'] ) ? $config_mod['template'] : "shortstory.tpl" ) . "\"></td></tr>";

$buffer .= "<tr><td class=\"col-xs-6 col-sm-6 col-md-7 white-line\"><h6 class=\"media-heading text-semibold\">Количество новостей на странице списков</h6><span>По умолчанию используется количество указаненое в настройках DLE</span></td><td class=\"col-xs-6 col-sm-6 col-md-7 white-line\"><input name=\"config[news_number]\" class=\"form-control\" value=\"" . ( isset( $config_mod['news_number'] ) ? $config_mod['news_number'] : "" ) . "\"></td></tr>";

echoheader( $__name, $__descr );

?>
<div class="row">
	<div class="col-md-12">
		<div class="<?=($config['version_id']>=12)?"panel":"box"?>">
		    <div class="<?=($config['version_id']>=12)?"panel-heading":"box-header"?>">
				<ul class="nav nav-tabs <?=($config['version_id']>=12)?"nav-tabs-solid":"nav-tabs-left"?>">
					<li class="active">
						<a href="#main" data-toggle="tab">
							<i class="icon-cog"></i> 
							Настройки
						</a>
					</li>					
				</ul>
			</div>

			<form id="config">
	            <div class="box-content">
	                <div class="tab-content">  	                  
		                <div class="tab-pane active" id="main">
	                    	<table class="table table-normal">
							    <tbody>
									<?=$buffer?>
							    </tbody>
							</table>							
	                    </div>
	                </div>
	                <div class="<?=($config['version_id']>=12)?"panel-footer":"box-footer"?> padded">
						<input onclick="save_config(); return false;" class="btn <?=($config['version_id']>=12)?"bg-teal":"btn-green"?>" type="submit" value="Сохранить настройки">

						<input onclick="switch_sections(); return false" class="btn <?=($config['version_id']>=12)?"btn-bluebg-primary-600":"btn-blue"?>" style="float: right;" type="button" value="Ссылка в меню «Сторонние модули» (вкл/выкл)">
					</div>
	            </div>
	        </form>
        </div>
    </div>
</div>

<script type="text/javascript">
function save_config() {	
	$.post('<?=$config['admin_path']?>?mod=<?=$mod?>&action=config', $('#config').serialize(), function(data){ 
		data = JSON.parse(data);
		DLEalert( data.message, '<?=$__name?>' );
	});  
}

function switch_sections() {	
	$.get('<?=$config['admin_path']?>?mod=<?=$mod?>&action=sections', null, function(data){
		data = JSON.parse(data);
		DLEalert( data.message, '<?=$__name?>' );
	});  
}
</script>

<div style="padding: 10px 0px 30px 0px;text-align: center;">
	Author: <a style="color: blue" href="http://zerocoolpro.biz/forum/members/icooler.3086/" target="_blank">iCooLER</a> | 
	Telegram: <a style="color: blue" href="tg://resolve?domain=thecoooler">@thecoooler</a>
</div>
<?php echofooter(); ?>