<?php

if( !defined( 'DATALIFEENGINE' ) OR !defined( 'LOGGED_IN' ) ) {
	die( "Hacking attempt!" );
}
if( $member_id['user_group'] != 1 ) {
	msg( "error", $lang['index_denied'], $lang['index_denied'] );
}

require_once (ENGINE_DIR.'/data/NotionConfig.php');
$start = microtime(true); 


if( $action == "save" ) {
    
	$save_con = $_POST['save_con'];
	$find = array();
	$replace = array();
	$find[] = "'\r'";
	$replace[] = "";
	$find[] = "'\n'";
	$replace[] = "";
	$save_con = $save_con;
	$handler = fopen( ENGINE_DIR . '/data/NotionConfig.php', "w" );
	
	fwrite( $handler, "<?PHP \n\n//Mymod_notion Configurations\n\n\$NtCnfg = array (\n" );
	foreach ( $save_con as $name => $value ) {
		$value = trim(strip_tags(stripslashes( $value )));
		$value = htmlspecialchars( $value, ENT_QUOTES, $config['charset']);
		$value = preg_replace( $find, $replace, $value );
			
		$name = trim(strip_tags(stripslashes( $name )));
		$name = htmlspecialchars( $name, ENT_QUOTES, $config['charset'] );
		$name = preg_replace( $find, $replace, $name );
		fwrite( $handler, "'{$name}' => '{$value}',\n" );
	}
	fwrite( $handler, ");\n\n?>" );
	fclose( $handler );
	
	clear_cache();
	if (function_exists('opcache_reset')) {
		opcache_reset();
	}
	msg( "info", $lang['opt_sysok'], $lang['opt_sysok_1'], "?mod=mymod_notion" );
}



function showRow($title = "", $description = "", $field = "", $class = "") {
	echo "<tr>
       <td class=\"col-xs-10 col-sm-6 col-md-7 {$class}\"><h6>{$title}</h6><span class=\"note large\">{$description}</span></td>
       <td class=\"col-xs-2 col-md-5 settingstd {$class}\">{$field}</td>
       </tr>";
}
function makeDropDown($options, $name, $selected) {
	$output = "<select class=\"uniform\" style=\"min-width:100px;\" name=\"$name\">\r\n";
	foreach ( $options as $value => $description ) {
		$output .= "<option value=\"$value\"";
		if( $selected == $value ) {
			$output .= " selected ";
		}
		$output .= ">$description</option>\n";
	}
	$output .= "</select>";
	return $output;
}
function makeCheckBox($name, $selected) {
	$selected = $selected ? "checked" : "";	
	return "<input class=\"switch\" type=\"checkbox\" name=\"$name\" value=\"1\" {$selected}> ";
}


echoheader("Модуль списка обновлений", "Админпанель модуля v. 1.0");

/**
 * Вывод блока настроек
 */

echo <<<HTML
<form action="?mod=mymod_NotiON&action=save" name="conf" id="conf" method="post">
<div class="panel">
  <div class="panel-body">
    <div class="title">{$lang['vconf_title']}</div>
  </div>
  <div class="table-responsive">
  <table class="table table-normal">
HTML;

	showRow( "1. Игнорируемые пользователи", "Можно указать ID пользователей новости которых будут игнорироваться в модуле. По умолчанию 0 или ничего", 
    "<input class=\"form-control\" type=text style=\"text-align: center;\" name=\"save_con[user_id]\" value=\"{$NtCnfg['user_id']}\" size=20>", "white-line" );

	showRow( "2. За сколько дней", "Укажите давность как давно редактируемые/обновленные новости должны сюда попасть/ <b>Пример, 5 и менее дней назад: 5</b>",
    "<input class=\"form-control\" type=text style=\"text-align: center;\" name=\"save_con[days]\" value=\"{$NtCnfg['days']}\" size=20>" );

    showRow( "3. Количесво новостей", "Максимальное количесво новостей, которое модуль будет искать в базе данных и прекратит поиск. <br> <b>Дла вывода на главной странице рекомедую использовать не большие значание, 5-20</b> зачем тянуть много строк если в принципе это лишнее. Нагрузка при 100(при 100, со всеми включенныйми пунктами сортировки время скрипта ~ 0.006-8с. время с выводом шаблонов 0.03-5с).",
    "<input class=\"form-control\" type=text style=\"text-align: center;\" name=\"save_con[limit]\" value=\"{$NtCnfg['limit']}\" size=20>" );

    showRow( "4. От куда использовать заголовок", "Заголовок новости будет использоваться стандарный, из TITLE-новости или исользовать из доп. поля? <br><b>Если из доп поля, то ниже указать название поля!</b>",
    makeDropDown( array ("0" => "Title-новости", "1" => "Доп.поле" ), "save_con[title_in]", "{$NtCnfg['title_in']}" ) );

    showRow( "4.1 Доп поля для заголовка", "Только если выбранно выше использовать из доп.полей",
    "<input class=\"form-control\" type=text style=\"text-align: center;\" name=\"save_con[xfield]\" value=\"{$NtCnfg['xfield']}\" size=20>" );

    showRow( "5. Причину редактирования", "От куда брать описание причины редактирования, из стандартноого поля новости или доп.поля? 
    <br><b>Если из доп поля, то ниже указать название поля!</b>",
    makeDropDown( array ("0" => "Новости", "1" => "Доп.поле" ), "save_con[reason_in]", "{$NtCnfg['reason_in']}" ) );

    showRow( "5.1 Доп.поля для причины", "Только если выбранно выше использовать из доп.полей",
    "<input class=\"form-control\" type=text style=\"text-align: center;\" name=\"save_con[reason_xfield]\" value=\"{$NtCnfg['reason_xfield']}\" size=20>" );

    showRow( "6. Обновление с последней активности", "Покажет информации, что были обновление за время пока вас не было на сайте, или обновление в режиме онлайн пока вы на сайте. Через сессии и js.
    <br><b>Присутствует кастыл для dleшой 'Последняя активность', нет дополительных запросов в БД!</b>",
    makeCheckBox( "save_con[upd_notsee]", "{$NtCnfg['upd_notsee']}" ) );

    showRow( "7. Сортировка по категориям", "Не проверяем на категории, либо выводим новости принадлежащие категориям или новости не принадлежащие категориям <b>п. 7.1</b>. <b>Если не выключено, то ниже указать категории!</b>",
    makeDropDown( array ("0" => "Выключено", "1" => "Из категории", "2" => "Кроме категорий" ), "save_con[cat_on]", "{$NtCnfg['cat_on']}" ) );

    showRow( "7.1 Перечислите категории через |","Только если выбранно сортировка по категоримя. <b>Если больше одной, то перечислять через знак |</b>",
    "<input class=\"form-control\" type=text style=\"text-align: center;\" name=\"save_con[notcat]\" value=\"{$NtCnfg['notcat']}\" size=20>" );

    showRow( "Что нужно знать","Нужно понимать, что <b>п. 2</b> и <b>п. 3</b> взаимосвязаны т.е.  находят нужное кол-во новостей по критерию даты. Выбор доп.поля для <b>п. 4 и 5</b> создаёт чуть-чуть-чууть большее время выполнения скрипта. Запрос к БД один. При нажатии на сохранить вы чистите кэш модуля в ручную. Автоматическая чистка кэша происходит при каждом обновлеини новости. Блок на главной и архив релизованны разными файлами просто потому что так.. :)",
    "webkubikc@gmail.com \ вёртстка шаблонов и не только ;)" );
    
echo <<<HTML
</table></div></div>

<center>
<input type="hidden" name="user_hash" value="{$dle_login_hash}" />
<button type="submit" class="btn bg-teal btn-raised position-left legitRipple"><i class="fa fa-floppy-o position-left"></i>Сохранить</button>
</center>



</form>
HTML;



echo 'Время выполнения скрипта: '.(microtime(true) - $start).' сек.';
$memory = (!function_exists('memory_get_usage')) ? '' : round(memory_get_usage()/1024/1024, 2) . 'MB';
echo $memory;

echofooter();

?>
