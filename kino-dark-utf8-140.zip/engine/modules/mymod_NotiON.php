<?php
if(!defined('DATALIFEENGINE')) {  die("Hacking attempt!"); }

//$start = microtime(true); 

if ( $is_logged ) {


require ENGINE_DIR.'/data/NotionConfig.php';
//$NtCnfg = array(
//    'user_id' => '0',          // кроме пользователей с id 0
//    'days' => '-700 day',      // за периуд Х дней назад 
//    'limit' => '7',            // максимальное количество новостей из бд
//    'title_in' => '1',         // использовать тайтл новости или дл.поля
//    'xfield' => 'title_ru',    // какое доп. поле брать для тайтла
//    'reason_in' => '0',        // использовать причину редактирования или доп.поля
//    'reason_xfield' => 'year', // какое доп. поле брать причиы редактирования
//    'upd_notsee' => '0',       // вклчить обновление с посл. активности. исправил через jq
//    'cat_on' => '0',           // включить выборку по категориям
//    'notcat' => '13',          // тогда перечислям категории
//);

$myConfig  = array(
'cachePrefix' => !empty($cachePrefix) ? $cachePrefix : 'archives',
'cacheSuffix' => !empty($cacheSuffix) ? $cacheSuffix : false
);

$cacheid = md5(implode('.', $NtCnfg));
$NotiON_main = false;    
$NotiON_main  = dle_cache($myConfig['cachePrefix'], $cacheid, $myConfig['cacheSuffix']); // Значение из кеша
    
    
if( !$NotiON_main){ // Если в кеше ничего нет
         
    // Если включена выборка по категориям    
    if($NtCnfg[cat_on] == 1 ){
        if( !empty($NtCnfg[notcat]) ){
            $catList = " AND category regexp '[[:<:]](".$NtCnfg[notcat].")[[:>:]]' ";
        }
    }elseif($NtCnfg[cat_on] == 2) {
        if( !empty($NtCnfg[notcat]) ){
            $catList = " AND category not regexp '[[:<:]](".$NtCnfg[notcat].")[[:>:]]' ";
        } 
    }   
    // Если включено игнорировать пользователей
    if( !empty($NtCnfg[user_id]) != 0){
        $ursList = " AND `user_id` NOT IN (".$NtCnfg[user_id].") ";
    }
    // Ставим по умолчаю лимит на 7 . можно удалить эту проверку.
    if( empty($NtCnfg[limit]) ) { $NtCnfg[limit] = 7; }
    settype( $NtCnfg[limit], "integer");
    // Дата поиска
    $lastdate = (int)date(time() - 86400 * $NtCnfg[days]);
        
        
    // Запрос к БД
    $xfields = $db->query("
    SELECT p.id, p.xfields, p.title, p.alt_name, p.category, e.editdate, e.reason 
    FROM ".PREFIX."_post p LEFT JOIN ".PREFIX."_post_extras e ON (p.id=e.news_id)
    WHERE (e.editdate > '".$lastdate."') 
    ".$catList."
    AND approve=1 
    ".$ursList."
    ORDER BY e.editdate DESC
    LIMIT ".$NtCnfg[limit]."
    ");
        
        
    $tpl->load_template('noti_ml.tpl'); /* ШАБЛОН */
        
    foreach($xfields as $value) {
        // От куда берем заголовок из титла или название с доп поля.
        if ($NtCnfg[title_in] == 0 && isset($NtCnfg[xfield]) ){
            $titleIn = $value['title'];
        } else {
            if($value[xfields]){ 
                $row = xfieldsdataload($value[xfields]); 
                $titleIn = !empty($row[$NtCnfg[xfield]]) ? $row[$NtCnfg[xfield]] : 'Поле заголовка пустое...';
            }
        }
        // От куда берем описания редактирований. из доп поля или из бд reason/  
        if($NtCnfg[reason_in] == 1 && isset($NtCnfg[reason_xfield]) ){
            if($value[xfields]){ 
                $row = xfieldsdataload($value[xfields]);
                $reasonIn = !empty($row[$NtCnfg[reason_xfield]]) ? $row[$NtCnfg[reason_xfield]] : 'Поле причины пустое...';
            }
        } else {
            $reasonIn = !empty($value['reason']) ? $value['reason'] : 'Не указанно... Увы :( Но загляуть стоит ';
        }
        $full_link = $config['http_home_url'] .$value['id']. "-" .$value['alt_name']. ".html";
            
        $category_id = $value['category'];
		if( strpos( $tpl->copy_template, "[catlist=" ) !== false ) {
			$tpl->copy_template = preg_replace_callback ( "#\\[(catlist)=(.+?)\\](.*?)\\[/catlist\\]#is", "check_category", $tpl->copy_template );
		}
            
        $tpl->set('{tag_title}', $titleIn);
        $tpl->set('{tag_reason}', $reasonIn);
        $tpl->set('{tag_link}', $full_link);
        $tpl->set('{tag_editdate}', $value['editdate']);
        $tpl->set('{tag_date}', langdate("d M. Y", $value['editdate']));
        $tpl->compile('noti_ml');  /* ШАБЛОН */
    }
    
    $NotiList = $tpl->result['noti_ml'];  /* ШАБЛОН */
    $tpl->clear($NotiList);  /* ШАБЛОН */
        
    $tpl->load_template('noti_m.tpl'); /* ШАБЛОН */
    $tpl->set('{tag_notiMain}', $NotiList);
    $tpl->compile('noti_m');  /* ШАБЛОН */
    $NotiON_main = $tpl->result['noti_m'];  /* ШАБЛОН */
    $tpl->clear();  /* ШАБЛОН */
    create_cache($myConfig['cachePrefix'], $NotiON_main, $cacheid, $myConfig['cacheSuffix']); // Записываем результат работы в кеш.   
}
echo $NotiON_main;
    
}

//echo 'Время выполнения скрипта: '.(microtime(true) - $start).' сек.';
//$memory = (!function_exists('memory_get_usage')) ? '' : round(memory_get_usage()/1024/1024, 2) . 'MB';
//echo $memory; 

?>