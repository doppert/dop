<?php
/*
=====================================================
YouWatch
-----------------------------------------------------
Автор : Gameer
-----------------------------------------------------
Site : http://gameer.name/
-----------------------------------------------------
Copyright (c) 2016 Gameer
=====================================================
Данный код защищен авторскими правами
*/

if( ! defined( 'DATALIFEENGINE' ) ) return;
$limit = is_numeric($limit) ? intval($limit) : 5;
$newsid = is_numeric($newsid) ? intval($newsid) : false;
if(!$newsid) return;
if($dle_module == "showfull")
{
	if(isset($_COOKIE['senpainoticeme']))
	{
		$array_senpainoticeme = explode(",",$_COOKIE['senpainoticeme']);
		array_unshift($array_senpainoticeme, $newsid);
		$array_senpainoticeme = array_unique($array_senpainoticeme);
		if(count($array_senpainoticeme) > $limit)
			$array_senpainoticeme = array_slice($array_senpainoticeme, 0, $limit, true);
		$array_senpainoticeme = implode(",", $array_senpainoticeme);
		set_cookie("senpainoticeme", $array_senpainoticeme, 7);
	}
	else
		set_cookie("senpainoticeme", $newsid, 7);
}
?>