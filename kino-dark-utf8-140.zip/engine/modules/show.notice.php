<?PHP
/*
=====================================================
YouWatch
-----------------------------------------------------
Автор : Gameer
-----------------------------------------------------
Site : http://gameer.name/
-----------------------------------------------------
Copyright (c) 2016 Gameer
=====================================================
Данный код защищен авторскими правами
*/
if(isset($_COOKIE['senpainoticeme']))
{
	$temp = empty($temp) ? "shortstory" : trim(strip_tags(stripslashes($temp)));
	$array_senpainoticeme = explode(",",$_COOKIE['senpainoticeme']);
	if(count($array_senpainoticeme))
	{
		foreach($array_senpainoticeme as $index => $val)
			$array_senpainoticeme[$index] = intval($val);
		$array_senpainoticeme = implode("','", $array_senpainoticeme);
		$sql_result = $db->query("SELECT * FROM " . PREFIX . "_post LEFT JOIN " . PREFIX . "_post_extras ON (" . PREFIX . "_post.id=" . PREFIX . "_post_extras.news_id) WHERE id IN ('".$array_senpainoticeme."')");
		$tpl->load_template( $temp . '.tpl' );
		include (ENGINE_DIR . '/modules/show.custom.php');
		echo $tpl->result['content'];
	}
}
?>