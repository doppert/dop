<?PHP
if(!defined('DATALIFEENGINE'))die("Hacking attempt!");
$aviable_news_numbers = array(15,50,100,200);
if($echolist){
    foreach($aviable_news_numbers as $v){
        echo "<option".($v == $config['news_number']?" selected":"").">$v</option>";
    }
}else{
    if(isset($_POST['set_news_number']) AND in_array($_POST['set_news_number'],$aviable_news_numbers)) $config['news_number'] = $_SESSION['news_number'] = intval( $_POST['set_news_number'] );
    elseif(isset($_SESSION['news_number']) AND in_array($_SESSION['news_number'],$aviable_news_numbers)) $config['news_number'] = $_SESSION['news_number'];
}
?>