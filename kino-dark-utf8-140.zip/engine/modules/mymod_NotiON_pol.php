<?php
if(!defined('DATALIFEENGINE')) {  die("Hacking attempt!"); }

if ( $is_logged ){
    
require_once  ENGINE_DIR.'/data/NotionConfig.php';

$myConfig  = array(
'cachePrefix' => !empty($cachePrefix) ? $cachePrefix : 'archives',
'cacheSuffix' => !empty($cacheSuffix) ? $cacheSuffix : false
);
    
$cacheid = md5(implode('_', $NtCnfg));
$NotiON_poln = false;   
$NotiON_poln  = dle_cache($myConfig['cachePrefix'], $cacheid,  $myConfig['cacheSuffix']); // Значение из кеша 
    
    
if( !$NotiON_poln){ // Если в кеше ничего нет
        
    // Если включена выборка по категориям    
    if($NtCnfg[cat_on] == 1 ){
        if( !empty($NtCnfg[notcat]) ){
            $catList = " AND category regexp '[[:<:]](".$NtCnfg[notcat].")[[:>:]]' ";
        }
    }elseif($NtCnfg[cat_on] == 2) {
        if( !empty($NtCnfg[notcat]) ){
            $catList = " AND category not regexp '[[:<:]](".$NtCnfg[notcat].")[[:>:]]' ";
        } 
    }   
    // Если включено игнорировать пользователей
    if( !empty($NtCnfg[user_id]) != 0){
        $ursList = " AND `user_id` NOT IN (".$NtCnfg[user_id].") ";
    }
        
    $xfields2 = $db->query("
    SELECT p.id, p.xfields, p.title, p.alt_name, p.category, e.editdate, e.reason
    FROM ".PREFIX."_post p LEFT JOIN ".PREFIX."_post_extras e ON (p.id=e.news_id)
    WHERE (e.editdate > '1000000000') 
    ".$catList."
    AND approve=1 
    ".$ursList."
    ORDER BY e.editdate DESC
    LIMIT 30
    ");
    
   $tpl->load_template('noti_fl.tpl'); /* ШАБЛОН */
    $cur_date = null;
    foreach($xfields2 as $value) {
            
        $date = date('d.m.Y', $value['editdate']);
        if($date != $cur_date) {
            $cur_date = $date;
            $tpl->set('{tag_data}', '<span class="date-ln">'.$date.'</span>');
        } else {
            $tpl->set('{tag_data}', '');
        }   
            
        // От куда берем заголовок из титла или название с доп поля.
        if ($NtCnfg[title_in] == 0 && isset($NtCnfg[xfield]) ){
            $titleIn = $value['title'];
        } else {
            if($value[xfields]){ //проверяем есть ли элемент в массиве
                $row = xfieldsdataload($value[xfields]); //получаем нужное нам доп поле
                $titleIn = !empty($row[$NtCnfg[xfield]]) ? $row[$NtCnfg[xfield]] : 'Поле заголовка пустое...';
            }
        }
        // От куда берем описания редактирований. из доп поля или из бд reason/  
        if($NtCnfg[reason_in] == 1 && isset($NtCnfg[reason_xfield]) ){
            if($value[xfields]){
                $row = xfieldsdataload($value[xfields]);
                $reasonIn = !empty($row[$NtCnfg[reason_xfield]]) ? $row[$NtCnfg[reason_xfield]] : 'Поле причины пустое...';
            }
        } else {
            $reasonIn = !empty($value['reason']) ? $value['reason'] : 'Не указанно... Увы :( Но загляуть стоит ';
        }
        $full_link = $config['http_home_url'] .$value['id']. "-" .$value['alt_name']. ".html"; 
            
		$category_id = $value['category'];
		if( strpos( $tpl->copy_template, "[catlist=" ) !== false ) {
			$tpl->copy_template = preg_replace_callback ( "#\\[(catlist)=(.+?)\\](.*?)\\[/catlist\\]#is", "check_category", $tpl->copy_template );
		}
            
        $tpl->set('{tag_link1}', $full_link);
        $tpl->set('{tag_title1}', $titleIn);
        $tpl->set('{tag_reason1}', $reasonIn);
        $tpl->compile('noti_fl');
    }
    $NotiON_poln = $tpl->result['noti_fl'];  /* ШАБЛОН */
    $tpl->clear();
    create_cache($myConfig['cachePrefix'], $NotiON_poln, $cacheid, $myConfig['cacheSuffix']); // Записываем результат работы в кеш.       
}
        
    $tpl->load_template('noti_full.tpl'); 
    $tpl->set('{tag_noti}', $NotiON_poln);
    $tpl->compile('content');  /* ШАБЛОН */
    $tpl->clear();  /* ШАБЛОН  */
    
} else { echo '<div class="notlogget">Вы не авторизованы для просмотра этой страницы</div>'; }
 

?>