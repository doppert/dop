function playlist_search(){
    var val = $('.playlist-main-search').val().toLowerCase().trim();
    $('.playlist-main-table tr, .playlist-main-none').show();
    var cat = $('.playlist-category-selector ul li.current').find('.playlist-cat-li-title').text();
    if(val.length>0 || cat!=''){
        $('.playlist-main-table tr').each(function(){
            var text = $(this).find('.playlist-main-table-title-text').text().toLowerCase();
            if((val.length>0 && text.indexOf(val)<0) || (cat!='' && $(this).data('category').indexOf(cat)<0 )) $(this).hide();
            else $('.playlist-main-none').hide();
        })
    }else if($('.playlist-main-table tr').length) $('.playlist-main-none').hide();
}
function playload(start){
    if(start) $('.playlist-add-window h3').addClass('pload');
    else $('.playlist-add-window h3').removeClass('pload');
}
$(document)
.on('click','body',function(e){
    if($(e.target).parents('.playlist-add-area').length<1){
        $('.playlist-add-window').fadeOut(200);
    }
})
.on('click','.playlist-add-trigger',function(e){
    e.preventDefault();
    $(".playlist-add-window").fadeToggle(200);
    if($(".playlist-add-loading").length){
        $.post(dle_root+"engine/ajax/controller.php?mod=playlists",{newsid:$(this).data('id'),action:'load'},function(d){
            if(d.error){
                $('.playlist-add-window').hide();
                DLEalert(d.error,'Ошибка');
            }else{
                $(".playlist-add-loading").remove();
                $(".playlist-add-window").append(d.html);
            }
        },"json")
    }
})
.on('keyup','.playlist-add-search',function(){
    var val = $(this).val().toLowerCase();
    $('.playlist-add-title').val($(this).val());
    $('.playlist-add-list li').show();
    if(val.length>0){
        $('.playlist-add-list li').each(function(){
            var text = $(this).find('span').text().toLowerCase();
            if(text.indexOf(val)<0) $(this).hide();
        })
    }
})
.on('click','.playlist-add-create-button',function(e){
    e.preventDefault();
    $('.playlist-add-create').slideDown(150);
    $(this).slideUp(150);
})
.on('click','.playlist-add-submit',function(e){
    e.preventDefault();
    var title = $('.playlist-add-title').val();
    if(title.length>2){
        playload(1);
        var personal = $('.playlist-add-private').prop('checked');
        $.post(dle_root+"engine/ajax/controller.php?mod=playlists",{title:title,personal:personal?1:0,action:'add'},function(d){
            playload(0);
            if(d.error){
                DLEalert(d.error,'Ошибка');
            }else{
                $('.playlist-add-title').val('');
                $('.playlist-add-list').append(d.html);
                $('.playlist-add-create').slideUp(150);
                $('.playlist-add-create-button').slideDown(150);
            }
        },"json")
    }
})
.on('click','.playlist-add-list li',function(e){
    e.preventDefault();
    playload(1);
    var $this = $(this);
    var newsid = $('.playlist-add-trigger').data('id');
    $.post(dle_root+"engine/ajax/controller.php?mod=playlists",{newsid:newsid,playlist:$(this).data('id'),action:'toggle'},function(d){
        playload(0);
        if(d.error){
            DLEalert(d.error,'Ошибка');
        }else{
            if(d.added) $this.addClass('current');
            else $this.removeClass('current');
        }
    },"json")
})
.on('click','.playlist-create-button',function(e){
    e.preventDefault();
    $('.playlist-add-dialog').dialog({
        width: '300px',
        buttons:{
            'Создать':function(){
                var $this = $(this);
                var title = $('.playlist-add-title').val();
                if(title.length>2){
                    ShowLoading();
                    $.post(dle_root+"engine/ajax/controller.php?mod=playlists",{title:title,personal:$('.playlist-add-private').prop('checked')?1:0,action:'add',user_id:$('.playlist-create-button').data('user')},function(d){
                        HideLoading(0);
                        if(d.error){
                            DLEalert(d.error,'Ошибка');
                            //alertWindow(d.error,1);
                        }else{
                            $('.playlist-add-title').val('');
                            $this.dialog('close');
                            DLEconfirm( 'Плейлист успешно создан. Обновить страницу?', dle_confirm, function(){
                                location.reload(true);
                            });
                        }
                    },"json")
                }
            },'Отмена':function(){
                $(this).dialog('close');
            }
        }
    })
})
.on('click','.playlist-main-editbutton',function(e){
    e.preventDefault();
    $('.playlist-edit-dialog').dialog({
        width: '500px',
        buttons:{
            'Сохранить':function(){
                ShowLoading();
                $.post(dle_root+"engine/ajax/controller.php?mod=playlists",{playlist:$('.playlist-main-header').data('id'),personal:$('.playlist-add-private').prop('checked')?1:0,title:$('.playlist-add-title').val(),descr:$('.playlist-add-descr').val(),action:'edit'},function(d){
                    HideLoading();
                    if(d.error){
                        DLEalert(d.error,'Ошибка');
                        //alertWindow(d.error,1);
                    }else{
                        DLEconfirm( dle_save_ok, dle_confirm, function(){
                            location.reload(true);
                        });
                    }
                },"json")
            },'Удалить':function(){
                if(!confirm('Точно удалить весь плейлист?')) return false;
                ShowLoading();
                $.post(dle_root+"engine/ajax/controller.php?mod=playlists",{playlist:$('.playlist-main-header').data('id'),action:'delete'},function(d){
                    HideLoading();
                    if(d.error){
                        DLEalert(d.error,'Ошибка');
                        //alertWindow(d.error,1);
                    }else window.location = d.url;
                },"json")
                
            },'Отмена':function(){
                $(this).dialog('close');
            }
        }
    })
})
.on('keyup','.playlist-main-search',function(){
    playlist_search();
})
.on('click','.playlist-category-selector-title',function(){
    $('.playlist-category-selector ul').slideToggle(150);
})
.on('mouseleave','.playlist-category-selector',function(){
    $('.playlist-category-selector ul').fadeOut(200);
})
.on('click','.playlist-category-selector ul li',function(){
    if($(this).hasClass('current')){
        $(this).removeClass('current');
        $('.playlist-category-selector-title').html( $('.playlist-category-selector-title').data('title') );
    }else{
        $(this).addClass('current').siblings().removeClass('current');
        $('.playlist-category-selector-title').html( $(this).find('.playlist-cat-li-title').text() );
    }
    playlist_search();
})
.on('click','.playlist-main-table-delete a',function(e){
    e.preventDefault();
    if(!confirm('Точно удалить?')) return false;
    var $this = $(this);
    ShowLoading();
    $.post(dle_root+"engine/ajax/controller.php?mod=playlists",{newsid:$this.data('id'),playlist:$('.playlist-main-header').data('id'),action:'toggle'},function(d){
        HideLoading();
        if(d.error){
            DLEalert(d.error,'Ошибка');
            //alertWindow(d.error,1);
        }else if(!d.added) $this.parents('tr').remove();
    },"json")
})
.on('mouseenter','[data-foto]',function(){
    var src = $(this).data('foto');
    $('.popfoto').remove();
    var left = $(this).offset().left + $(this).width() + 50;
    $('body').append('<img src="'+src+'" class="popfoto" style="top:'+$(this).offset().top+'px;left:'+left+'px;" />');
    $('.popfoto').animate({left: '-=40',opacity: 1},200,'linear');
})
.on('mouseleave','[data-foto]',function(){
    $('.popfoto').fadeOut(150);
})

var rcats = [];
$('.rcats').each(function(i, j){
    var t = $(this), cats = t.text();
    t.parents('tr').attr('data-category', cats);
    $.each(cats.split('/'), function(x, y){
        var cat = y.trim();
        rcats[cat] = (rcats[cat]==undefined) ? 1 : rcats[cat]+1;
    });
});

var li_cats = '';
for( var i in rcats){
    li_cats += '<li><span class="playlist-cat-li-title">'+i+'</span> <span class="playlist-cat-li-count">'+rcats[i]+'</span></li>';
}

$('.playlist-category-selector ul').html(li_cats);



