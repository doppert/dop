<?PHP 

$emoticon_config = array (

'voted_num' => '3',

'percent_voted' => '30',

'limit_voted' => '0',

'news_number' => '2',

'combination_count' => '4',

'category' => '',

'speedbar_separator' => '|',

'speedbar_title' => 'Эмодзи',

'cache' => '1',

'order_percent' => '1',

'template_news' => 'shortstory.tpl',

'info_template' => 'info.tpl',

'redirect' => '0',

'emoticon_cache' => '1',

);

?>