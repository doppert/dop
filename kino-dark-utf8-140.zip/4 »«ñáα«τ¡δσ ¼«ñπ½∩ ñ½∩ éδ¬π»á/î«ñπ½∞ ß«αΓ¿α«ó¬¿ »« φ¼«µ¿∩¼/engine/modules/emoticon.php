<?php
if( !defined('DATALIFEENGINE') ) {
	header( "HTTP/1.1 403 Forbidden" );
	header ( 'Location: ../../' );
	die( "Hacking attempt!" );
}

if ( !$is_logged ) {
	
	$tpl->load_template( 'info.tpl' );
	$tpl->set( '{error}', 'Ошибка' );
	$tpl->set( '{title}', 'Данный раздел могут смотреть лишь зарегестрированные пользователи.' );
	$tpl->compile( 'content' );
	$tpl->clear();
	
} else {
	
	if ( file_exists( ENGINE_DIR . '/data/emoticon_config.php' ) ) {
	   @require_once (ENGINE_DIR . '/data/emoticon_config.php');
	} else $emoticon_config = array ();	
	


if ( $cstart ) {
	
	$cstart = $cstart - 1;
	$cstart = $cstart * $config['news_number'];
	
}

if( isset($_REQUEST['emoticon_ids']) ) {
	$ids = explode(',', $_REQUEST['emoticon_ids']);
	if( $config['allow_alt_url'] ) $query_string = implode(',', $ids);
	else $query_string = "&emoticon_ids=" . implode(',', $ids);
} else {$ids = array(); $query_string = "";}

if($category) {
	
	if( $config['allow_alt_url'] ) $category_string = $category . "/";
	else $category_string = "&category=". $category;
	
} else $category_string = "";

$news_sort_by = $config['news_sort'];
$news_direction_by = $config['news_msort'];

$tpl->load_template( 'emoticon_main.tpl' );

if( stripos ( $tpl->copy_template, "[cat-list" ) !== false ) {

	if( preg_match("#\\[cat-list\\](.+?)\\[/cat-list\\]#is",$tpl->copy_template,$matches) ) {
			
		$cat_list = array();
		$cat_tmp = explode(',', $emoticon_config['category']);

		if( count($cat_tmp) ) {
			
			array_unshift($cat_tmp, "0");
			
			foreach( $cat_tmp as $val ) {

				$temp = $matches[1];
				
				if( $category AND $category == $cat_info[$val]['alt_name'] ) {

					$temp = str_ireplace("[active]", "",$temp);
					$temp = str_ireplace("[/active]", "",$temp);				
					
				} else {
					
					if(!$val AND !$category) {
						
						$temp = str_ireplace("[active]", "",$temp);
						$temp = str_ireplace("[/active]", "",$temp);
						
					} else $temp = preg_replace("/\[active\](.*?)\[\/active\]/is", "", $temp);
					
				}
				
				if(!$val) {
					
					$temp = str_ireplace("{name}" , "- Все категории -", $temp);
					if( $config['allow_alt_url'] ) $temp = str_ireplace("{url}" , $config['http_home_url']."emoticon/".$query_string, $temp);
					else $temp = str_ireplace("{url}" , $config['http_home_url']."?do=emoticon".$query_string, $temp);
					
				} else {
					
					$temp = str_ireplace("{name}" , $cat_info[$val]['name'], $temp);
					if( $config['allow_alt_url'] ) $temp = str_ireplace("{url}" , $config['http_home_url'].$cat_info[$val]['alt_name']."/emoticon/".$query_string, $temp);
					else $temp = str_ireplace("{url}" , $config['http_home_url']."?do=emoticon&category=" . $cat_info[$val]['alt_name'].$query_string, $temp);
					
				}				
				
				$cat_list[] = $temp;
			}
		
		}		
				
	}
		
	if ( $matches[0] ) $tpl->copy_template = str_replace($matches[0], implode($cat_list), $tpl->copy_template);

}

if (stripos ( $tpl->copy_template, "[list" ) !== false ) {

	if( preg_match("#\\[list\\](.+?)\\[/list\\]#is",$tpl->copy_template,$matches) ) {
			
		$list = array();

		foreach( $emoticon_list as $key => $val ) {
				
			$temp = $matches[1];
			$temp = str_ireplace("{name}" ,$val['name'], $temp);
			
            if( preg_match('/jpg|jpeg|png/is', $val['icon']) ) {
				
				$icon = "<img src=\"{$config['http_home_url']}uploads/emoticon/" . totranslit($val['icon']) . "\" />";
				
            } else $icon = "<b>" . $val['icon'] . "</b>";			
			
			$temp = str_ireplace("{icon}", $icon, $temp);
			$temp = str_ireplace("{id}", $key, $temp);
			
			if( in_array($key, $ids) ) {
				
				$remove_id = array_flip($ids);
				unset($remove_id[$key]);
				$remove_id = array_flip($remove_id);
				$curr_id = (count($remove_id) ? implode(',',$remove_id) : '');
				//$temp = str_ireplace("{ids}", (count($remove_id) ? implode(',',$remove_id) : ''), $temp);
				$temp = str_ireplace("[active]", "",$temp);
				$temp = str_ireplace("[/active]", "",$temp);
					
			} else {
				$curr_id = (count($ids) ? implode(',',$ids).',' : '').$key;
				//$temp = str_ireplace("{ids}", (count($ids) ? implode(',',$ids).',' : '').$key, $temp);
				$temp = preg_replace("/\[active\](.*?)\[\/active\]/is", "", $temp);				
			}

			if( $config['allow_alt_url'] ) $temp = str_ireplace("{url}" , $config['http_home_url'].$category_string."emoticon/" . $curr_id, $temp);
			else {
				if( $curr_id ) $temp = str_ireplace("{url}" , $config['http_home_url']."?do=emoticon{$category_string}&emoticon_ids=" . $curr_id, $temp);
				else $temp = str_ireplace("{url}" , $config['http_home_url']."?do=emoticon{$category_string}", $temp);
			}
			$list[] = $temp;
		}			
				
	}
		
	if ( $matches[0] ) {

	$tpl->copy_template = str_replace($matches[0], implode($list), $tpl->copy_template);	
	}
}

$tpl->set( '{max}', $emoticon_config['combination_count'] );
$tpl->set( '{current}', count($ids) );
$tpl->set( '{ids}', count($ids) ? implode(',', $ids) : '' );
$tpl->set( '{cat-name}', $category ? $cat_info[get_ID($cat_info, $category)]['alt_name'] : '- Все категории -' );
$tpl->set( '{name}', $emoticon_config['speedbar_title'] ? $emoticon_config['speedbar_title'] : 'Подборки' );
$tpl->compile( 'content' );
$tpl->clear();
$stop = false;
if( count($ids) > $emoticon_config['combination_count'] ) {
	$stop = true;
	if( $emoticon_config['redirect'] ) {

		array_splice($ids, 0, -$emoticon_config['combination_count']);

		if( $config['allow_alt_url'] ) $re_url = $config['http_home_url'].$category_string."emoticon/" . implode(',', $ids);	
		else $re_url = $config['http_home_url']."?do=emoticon{$category_string}&emoticon_ids=" . implode(',', $ids);
		
		if( $_POST['ajax'] == 'yes' ) die("{\"success\":false, \"redirect\":\"{$re_url}\"}");
		else {	
			header("HTTP/1.0 301 Moved Permanently");
			header("Location: {$re_url}");
		}	
		
	} else {

		$tpl->load_template( $emoticon_config['info_template'] );
		$tpl->set( '{error}', 'Превышено максимально допустимое количество комбинаций.' );
		$tpl->set( '{title}', 'Ошибка.' );
		$tpl->compile( 'content' );
		$tpl->clear();
		
	}

}

if( $ids AND !$stop ) {
	
	$thisdate = date ( "Y-m-d H:i:s", time () );
	$where_date = "";
	
	if( $category ) $where_category = " AND category regexp '[[:<:]](" . get_ID($cat_info, $category) . ")[[:>:]]'";
	else $where_category = "";
	
	if( count($ids) > 1 ) {
				
		$params = array();
		
		foreach( $ids as $val  ) {

			$params[] = "emoticon_ids regexp '[[:<:]](" . $val . ")[[:>:]]'";
		}
		
		$params = implode(' AND ', $params);
		$where = "{$params}{$where_date}";

		
	} else $where = "emoticon_ids regexp '[[:<:]](" . $ids[0] . ")[[:>:]]'{$where_date}";
	
/*
	$sql_count = "SELECT GROUP_CONCAT(DISTINCT `news_id`) as `ids` FROM " . PREFIX . "_post p LEFT JOIN " . PREFIX . "_post_emoticon t ON (p.id=t.news_id) WHERE {$where}{$where_category}";	
	
	$sql_select = "SELECT DISTINCT p.id, p.autor, p.date, p.short_story, CHAR_LENGTH(p.full_story) as full_story, p.xfields, p.title, p.category, p.alt_name, p.comm_num, p.allow_comm, p.fixed, p.tags, e.news_read, e.allow_rate, e.rating, e.vote_num, e.votes, e.view_edit, e.editdate, e.editor, e.reason FROM " . PREFIX . "_post p LEFT JOIN " . PREFIX . "_post_extras e ON (p.id=e.news_id) LEFT JOIN " . PREFIX . "_post_emoticon t ON (p.id=t.news_id) WHERE {$where}{$where_category} LIMIT " . $cstart . "," . $config['news_number'];	
*/
	
	$sql_count = "SELECT GROUP_CONCAT(DISTINCT `news_id`) as `ids` FROM " . PREFIX . "_post p LEFT JOIN " . PREFIX . "_post_emoticon_search t ON (p.id=t.news_id) WHERE {$where}{$where_category}";	
	
	$sql_select = "SELECT DISTINCT p.id, p.autor, p.date, p.short_story, CHAR_LENGTH(p.full_story) as full_story, p.xfields, p.title, p.category, p.alt_name, p.comm_num, p.allow_comm, p.fixed, p.tags, e.news_read, e.allow_rate, e.rating, e.vote_num, e.votes, e.view_edit, e.editdate, e.editor, e.reason FROM " . PREFIX . "_post p LEFT JOIN " . PREFIX . "_post_extras e ON (p.id=e.news_id) LEFT JOIN " . PREFIX . "_post_emoticon_search t ON (p.id=t.news_id) WHERE {$where}{$where_category} LIMIT " . $cstart . "," . $config['news_number'];	
	
	$sql_result = $db->query( $sql_select );
	$tpl_news = $emoticon_config['template_news'] ? $emoticon_config['template_news'] : 'shortstory.tpl';
		
	$tpl->load_template( $tpl_news );
	include (DLEPlugins::Check(ENGINE_DIR . '/modules/show.custom.php'));

	
	if ( $sql_count) {

		$count_all = $db->super_query( $sql_count );

		$count_all = $count_all['ids'] ? count(explode(',', $count_all['ids'])) : 0;
	
	}
	
	if( !$count_all ) {
		
		$tpl->load_template( $emoticon_config['info_template'] );
		$tpl->set( '{error}', 'Ничего не найдено' );
		$tpl->set( '{title}', 'Ошибка.' );
		$tpl->compile( 'content' );
		$tpl->clear();		
		
	}

	if( $count_all AND $news_found) {

		$tpl->load_template( 'navigation.tpl' );
			
		//----------------------------------
		// Previous link
		//----------------------------------
			

		$no_prev = false;
		$no_next = false;
		if (isset ( $_GET['cstart'] )) $cstart = intval ( $_GET['cstart'] ); else $cstart = 1;
			
		if( isset( $cstart ) and $cstart != "" and $cstart > 1 ) {
			$prev = $cstart - 1;

			if( $config['allow_alt_url'] ) {

				if ($prev == 1)
					$prev_page = $url_page . "/{$category_string}emoticon/{$_GET['emoticon_ids']}";
				else
					$prev_page = $url_page . "/{$category_string}emoticon/{$_GET['emoticon_ids']}/page/" . $prev . "/";

				$tpl->set_block( "'\[prev-link\](.*?)\[/prev-link\]'si", "<a href=\"" . $prev_page . "\">\\1</a>" );

			} else {
					
				if ($prev == 1) {
						
					if ($user_query) $prev_page = $PHP_SELF . "?do=emoticon{$category_string}&emoticon_ids={$_GET['emoticon_ids']}" . $user_query;
					else $prev_page = $config['http_home_url'] . "?do=emoticon{$category_string}&emoticon_ids={$_GET['emoticon_ids']}";
						
				} else {
						
					if ($user_query) $prev_page = $PHP_SELF . "?do=emoticon{$category_string}&emoticon_ids={$_GET['emoticon_ids']}&cstart=" . $prev . "&amp;" . $user_query;
					else $prev_page = $PHP_SELF . "?do=emoticom{$category_string}&emoticon_ids={$_GET['emoticon_ids']}&cstart=" . $prev;
					
				}

				$tpl->set_block( "'\[prev-link\](.*?)\[/prev-link\]'si", "<a href=\"" . $prev_page . "\">\\1</a>" );
			}
			
		} else {
			$tpl->set_block( "'\[prev-link\](.*?)\[/prev-link\]'si", "<span>\\1</span>" );
			$no_prev = TRUE;
		}
			
		//----------------------------------
		// Pages
		//----------------------------------
		if( $config['news_number'] ) {

			$pages = "";
				
			if( $count_all > $config['news_number'] ) {
					
				$enpages_count = @ceil( $count_all / $config['news_number'] );
					
				if( $enpages_count <= 10 ) {
						
					for($j = 1; $j <= $enpages_count; $j ++) {
							
						if( $j != $cstart ) {
								
							if( $config['allow_alt_url'] ) {

								if ($j == 1)
									$pages .= "<a href=\"" . $url_page . "/{$category_string}emoticon/{$_GET['emoticon_ids']}/\">$j</a> ";
								else
									$pages .= "<a href=\"" . $url_page . "/{$category_string}emoticon/{$_GET['emoticon_ids']}/page/" . $j . "/\">$j</a> ";

							} else {

								if ($j == 1) {
										
									if ($user_query) {
										$pages .= "<a href=\"{$PHP_SELF}?do=emoticon{$category_string}&emoticon_ids={$_GET['emoticon_ids']}{$user_query}\">$j</a> ";
									} else $pages .= "<a href=\"{$config['http_home_url']}?do=emoticon{$category_string}&emoticon_ids={$_GET['emoticon_ids']}\">$j</a> ";
										
								} else {
										
									if ($user_query) {
										$pages .= "<a href=\"$PHP_SELF?do=emoticon{$category_string}&emoticon_ids={$_GET['emoticon_ids']}&cstart=$j&amp;$user_query\">$j</a> ";
									} else $pages .= "<a href=\"$PHP_SELF?do=emoticon{$category_string}&emoticon_ids={$_GET['emoticon_ids']}&cstart=$j\">$j</a> ";
										
								}

							}
							
						} else {
								
							$pages .= "<span>$j</span> ";
							
						}
						
					}
					
				} else {
						
					$start = 1;
					$end = 10;
					$nav_prefix = "<span class=\"nav_ext\">{$lang['nav_trennen']}</span> ";
						
					if( $cstart > 0 ) {
							
						if( $cstart > 6 ) {
								
							$start = $cstart - 4;
							$end = $start + 8;
								
							if( $end >= $enpages_count-1 ) {
								$start = $enpages_count - 9;
								$end = $enpages_count - 1;
							}
							
						}
						
					}
						
					if( $end >= $enpages_count-1 ) $nav_prefix = ""; else $nav_prefix = "<span class=\"nav_ext\">{$lang['nav_trennen']}</span> ";
					
					if( $start >= 2 ) {
							
						if( $start >= 3 ) $before_prefix = "<span class=\"nav_ext\">{$lang['nav_trennen']}</span> "; else $before_prefix = "";

						if( $config['allow_alt_url'] ) $pages .= "<a href=\"" . $url_page . "/emoticon/{$_GET['emoticon_ids']}/\">1</a> ".$before_prefix;
						else {
							if($user_query) $pages .= "<a href=\"$PHP_SELF?do=emoticon{$category_string}&emoticon_ids={$_GET['emoticon_ids']}&{$user_query}\">1</a> ".$before_prefix;
							else $pages .= "<a href=\"{$config['http_home_url']}?do=emoticon{$category_string}&emoticon_ids={$_GET['emoticon_ids']}\">1</a> ".$before_prefix;
						}
					
					}
						
					for($j = $start; $j <= $end; $j ++) {
							
						if( $j != $cstart ) {

							if( $config['allow_alt_url'] ) {

								if ($j == 1)
									$pages .= "<a href=\"" . $url_page . "/{$category_string}emoticon/{$_GET['emoticon_ids']}/\">$j</a> ";
								else
									$pages .= "<a href=\"" . $url_page . "/{$category_string}emoticon/{$_GET['emoticon_ids']}/page/" . $j . "/\">$j</a> ";

							} else {

								if ($j == 1) {
										
									if ($user_query) {
										$pages .= "<a href=\"{$PHP_SELF}?do=emoticon{$category_string}&emoticon_ids={$_GET['emoticon_ids']}&{$user_query}\">$j</a> ";
									} else $pages .= "<a href=\"{$config['http_home_url']}?do=emoticon{$category_string}&emoticon_ids={$_GET['emoticon_ids']}\">$j</a> ";
										
								} else {
										
									if ($user_query) {
										$pages .= "<a href=\"$PHP_SELF?do=emoticon{$category_string}&emoticon_ids={$_GET['emoticon_ids']}&cstart=$j&amp;$user_query\">$j</a> ";
									} else $pages .= "<a href=\"$PHP_SELF?do=emoticon{$category_string}&emoticon_ids={$_GET['emoticon_ids']}&cstart=$j\">$j</a> ";
										
								}

							}
							
						} else {
								
							$pages .= "<span>$j</span> ";
							
						}
						
					}
						
					if( $cstart != $enpages_count ) {
						if( $config['allow_alt_url'] ) {
								
							$pages .= $nav_prefix . "<a href=\"" . $url_page . "/{$category_string}emoticon/{$_GET['emoticon_ids']}/page/{$enpages_count}/\">{$enpages_count}</a>";
								
						} else {
								
							if ($user_query) $pages .= $nav_prefix . "<a href=\"$PHP_SELF?do=emoticon{$category_string}&emoticon_ids={$_GET['emoticon_ids']}&cstart={$enpages_count}&amp;$user_query\">{$enpages_count}</a>";
							else $pages .= $nav_prefix . "<a href=\"$PHP_SELF?do=emoticon{$category_string}&emoticon_ids={$_GET['emoticon_ids']}&cstart={$enpages_count}\">{$enpages_count}</a>";
								
						}
						
					} else $pages .= "<span>{$enpages_count}</span> ";

				
				}
				
				$tpl->set( '{pages}', $pages );
			}
			
			//----------------------------------
			// Next link
			//----------------------------------

			if( $config['news_number'] AND $config['news_number'] < $count_all AND $cstart < $enpages_count ) {
				$next_page = $cstart + 1;
				
				
				if( $config['allow_alt_url'] ) {
					$next = $url_page . "/{$category_string}emoticon/{$_GET['emoticon_ids']}/page/" . $next_page . '/';
					$tpl->set_block( "'\[next-link\](.*?)\[/next-link\]'si", "<a href=\"" . $next . "\">\\1</a>" );
				} else {
					
					if ($user_query) $next = $PHP_SELF . "?do=emoticon{$category_string}&emoticon_ids={$_GET['emoticon_ids']}&cstart=" . $next_page . "&amp;" . $user_query;
					else $next = $PHP_SELF . "?do=emoticom{$category_string}&emoticon_ids={$_GET['emoticon_ids']}&cstart=" . $next_page;
				
					
					$tpl->set_block( "'\[next-link\](.*?)\[/next-link\]'si", "<a href=\"" . $next . "\">\\1</a>" );
				}
			
			} else {
				$tpl->set_block( "'\[next-link\](.*?)\[/next-link\]'si", "<span>\\1</span>" );
				$no_next = TRUE;
			}
			
			if( !$no_prev OR !$no_next ) {
				$tpl->compile( 'navi' );

				switch ( $config['news_navigation'] ) {

					case "2" :
						
						$tpl->result['content'] = $tpl->result['navi'].$tpl->result['content'];
						break;

					case "3" :
						
						$tpl->result['content'] = $tpl->result['navi'].$tpl->result['content'].$tpl->result['navi'];
						break;

					default :
						$tpl->result['content'] .= $tpl->result['navi'];
						break;
				
				}
			}
			
			$tpl->clear();
		}

	}
			
	if ($config['files_allow']) if (strpos ( $tpl->result['content'], "[attachment=" ) !== false) {
		$tpl->result['content'] = show_attach ( $tpl->result['content'], $attachments );
	}

}

if( $_POST['ajax'] == 'yes' ) {

	
	$nam_e = $emoticon_config['speedbar_title'] ? $emoticon_config['speedbar_title'] : 'Подборки';
	$s_navigation = "<span itemscope itemtype=\"http://data-vocabulary.org/Breadcrumb\"><a href=\"{$config['http_home_url']}\" itemprop=\"url\"><span itemprop=\"title\">" . $config['short_title'] . "</span></a></span>";
	
	if (intval($category_id)){
		
		if($titl_e OR (isset($_GET['cstart']) AND intval($_GET['cstart']) > 1) ) {
			$last_link = true;
		} else $last_link = false;
		
			if($do == 'emoticon') {
			
				if(!isset($_GET['emoticon_ids'])) $s_navigation .= " {$config['speedbar_separator']} <span itemscope itemtype=\"http://data-vocabulary.org/Breadcrumb\"><a href=\"?do=emoticon\" itemprop=\"url\"><span itemprop=\"title\">{$nam_e}</span></a></span>";
				else {
					$s_navigation .= " {$config['speedbar_separator']} <span itemscope itemtype=\"http://data-vocabulary.org/Breadcrumb\"><a href=\"?do=emoticon\" itemprop=\"url\"><span itemprop=\"title\">{$nam_e}</span></a></span>";
					$emoticon_config['speedbar_separator'] = ( $emoticon_config['speedbar_separator'] ? $emoticon_config['speedbar_separator'] : $config['speedbar_separator']);	
					$s_navigation .= " {$config['speedbar_separator']} " . get_breadcrumb_emoticon ( $_GET['emoticon_ids'], " {$emoticon_config['speedbar_separator']} ", true );
				}
			}
		$s_navigation .= " {$config['speedbar_separator']} " . get_breadcrumbcategories ( intval($category_id), $config['speedbar_separator'], $last_link );

	} elseif($do == 'emoticon') {

		if( (isset($_GET['cstart']) AND intval($_GET['cstart']) > 1) ) {
			$last_link = true;
		} else $last_link = false;
		
		$emoticon_config['speedbar_separator'] = ( $emoticon_config['speedbar_separator'] ? $emoticon_config['speedbar_separator'] : $config['speedbar_separator']);	
		if(!isset($_GET['emoticon_ids'])) $s_navigation .= " {$config['speedbar_separator']} " . $nam_e;
		else {
			$s_navigation .= " {$config['speedbar_separator']} <span itemscope itemtype=\"http://data-vocabulary.org/Breadcrumb\"><a href=\"?do=emoticon\" itemprop=\"url\"><span itemprop=\"title\">{$nam_e}</span></a></span>";
			$s_navigation .= " {$config['speedbar_separator']} " . get_breadcrumb_emoticon ( $_GET['emoticon_ids'], " {$emoticon_config['speedbar_separator']} ", $last_link );
		}
  
	} elseif ($nam_e) $s_navigation .= " {$config['speedbar_separator']} " . $nam_e;
	
	if ( isset($_GET['cstart']) AND intval($_GET['cstart']) > 1 ){
		
		$page_extra = " {$config['speedbar_separator']} ".$lang['news_site']." ".intval($_GET['cstart']);
		
	} else $page_extra = '';

	$s_navigation .= $page_extra;
	
	$return_speedbar = addcslashes($s_navigation, "\t\n\r\"\\/");
	$return_box = addcslashes($tpl->result['content'], "\t\n\r\"\\/");
	$count_all = $count_all ? $count_all : 0;
	
	echo "{\"success\":true, \"returnbox\":\"{$return_box}\", \"speedbar\":\"{$return_speedbar}\", \"count_news\":\"{$count_all}\"}";
	die();
}
}
?>