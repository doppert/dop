<?PHP
if( !defined( 'DATALIFEENGINE' ) OR !defined( 'LOGGED_IN' ) ) {
	die( "Hacking attempt!" );
}


	if ( file_exists( ENGINE_DIR . '/data/emoticon_config.php' ) ) {
	   @require_once (ENGINE_DIR . '/data/emoticon_config.php');
	} else $emoticon_config = array ();	

	$emoticon_list = get_vars ( "emoticon_list" );

	$action = $action ? $action : "settings";
	$id = intval( $_REQUEST['id'] );

	$menu_active_settings = " class=\"active\"";
	$menu_active_list = "";
	
	if( $action == "list") {
  
		$lang['tabs_gr_all'] = $lang['header_tm_1'];
		$menu_active_list = " class=\"active\"";
		$menu_active_settings = "";
		$add_template = "<div style=\"display:inline-block;\">
		 <a href=\"/{$config['admin_path']}?mod=emoticon&action=add\"><i class=\"fa fa-plus-circle\"></i> Добавить ?</a>
		</div>";
  
	}

    function saveFile($path, $filename) {

		$filename = totranslit( $filename );

        if(!@move_uploaded_file($_FILES['qqfile']['tmp_name'], $path.$filename)){
            return false;
        }

        return $filename;
    }	
	
	function check_filename ( $filename ) {
		global $config;
		
		if( $filename != "" ) {

			$filename = str_replace( "\\", "/", $filename );
			$filename = preg_replace( '#[.]+#i', '.', $filename );
			$filename = str_replace( "/", "", $filename );
			$filename = str_ireplace( "php", "", $filename );

			$filename_arr = explode( ".", $filename );
			
			if(count($filename_arr) < 2) {
				return false;
			}
			
			$type = totranslit( end( $filename_arr ) );
			
			if(!$type) return false;
			
			$curr_key = key( $filename_arr );
			unset( $filename_arr[$curr_key] );
 
			$filename = totranslit( implode( "_", $filename_arr ) );
			
			if( !$filename ) {
				$filename = time() + rand( 1, 100 );
			}
			
			$filename = $filename . "." . $type;

		} else return false;

		$filename = preg_replace( '#[.]+#i', '.', $filename );

		if( stripos ( $filename, ".php" ) !== false ) return false;
		if( stripos ( $filename, ".phtm" ) !== false ) return false;
		if( stripos ( $filename, ".shtm" ) !== false ) return false;
		if( stripos ( $filename, ".htaccess" ) !== false ) return false;
		if( stripos ( $filename, ".cgi" ) !== false ) return false;
		if( stripos ( $filename, ".htm" ) !== false ) return false;
		if( stripos ( $filename, ".ini" ) !== false ) return false;

		if( stripos ( $filename, "." ) === 0 ) return false;
		if( stripos ( $filename, "." ) === false ) return false;
		
		if( dle_strlen( $filename, $config['charset'] ) > 170 ) {
			return false;
		}

		return $filename;

	}
	
    function getFileName() {

		$path_parts = @pathinfo($_FILES['qqfile']['name']);

        return $path_parts['basename'];

    }
    function getFileSize() {
        return $_FILES['qqfile']['size'];
    }

    function getErrorCode() {

		$error_code = $_FILES['qqfile']['error'];

		if ($error_code !== UPLOAD_ERR_OK) {

		    switch ($error_code) { 
		        case UPLOAD_ERR_INI_SIZE: 
		            $error_code = 'PHP Error: The uploaded file exceeds the upload_max_filesize directive in php.ini'; break;
		        case UPLOAD_ERR_FORM_SIZE: 
		            $error_code = 'PHP Error: The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form'; break;
		        case UPLOAD_ERR_PARTIAL: 
		            $error_code = 'PHP Error: The uploaded file was only partially uploaded'; break;
		        case UPLOAD_ERR_NO_FILE: 
		            $error_code = 'PHP Error: No file was uploaded'; break;
		        case UPLOAD_ERR_NO_TMP_DIR: 
		            $error_code = 'PHP Error: Missing a PHP temporary folder'; break;
		        case UPLOAD_ERR_CANT_WRITE: 
		            $error_code = 'PHP Error: Failed to write file to disk'; break;
		        case UPLOAD_ERR_EXTENSION: 
		            $error_code = 'PHP Error: File upload stopped by extension'; break;
		        default: 
		            $error_code = 'Unknown upload error';  break;
		    } 

		} else return false;

        return $error_code;
    }
	
	function showRow($title = "", $description = "", $field = "", $class = "") {
		echo "<tr>
        <td class=\"col-xs-6 col-sm-6 col-md-7\"><h6 class=\"media-heading text-semibold\">{$title}</h6><span class=\"text-muted text-size-small hidden-xs\">{$description}</span></td>
        <td class=\"col-xs-6 col-sm-6 col-md-5\">{$field}</td>
        </tr>";
	}
	
	function makeCheckBox($name, $selected) {

		$selected = $selected ? "checked" : "";
	
		return "<input class=\"switch\" type=\"checkbox\" name=\"{$name}\" value=\"1\" {$selected}>";

	}

	function makeDropDown($options, $name, $selected) {
		$output = "<select class=\"uniform\" style=\"opacity:0;\" name=\"$name\">\r\n";
		foreach ( $options as $value => $description ) {
			$output .= "<option value=\"$value\"";
			if( $selected == $value ) {
				$output .= " selected ";
			}
			$output .= ">$description</option>\n";
		}
		$output .= "</select>";
		return $output;
	}

	$category = CategoryNewsSelection(0);
	$category_select = CategoryNewsSelection((empty($emoticon_config['category']) ? 0 : explode(',', $emoticon_config['category'])));
	
if( $action == "settings" ) {
	
	if( $_REQUEST['is'] == "save" ) {
		
		if( $_REQUEST['user_hash'] == "" or $_REQUEST['user_hash'] != $dle_login_hash ) {
			
			die( "Hacking attempt!" );
		
		}
		
		$save_con = $_POST['save_con'];
		$save_con['voted_num'] = intval($save_con['voted_num']);	
		$save_con['limit_voted'] = intval($save_con['limit_voted']);	
		$save_con['percent_voted'] = intval($save_con['percent_voted']);	
		$save_con['news_number'] = intval($save_con['news_number']);	
		$save_con['combination_count'] = intval($save_con['combination_count']);	
		$save_con['cache'] = intval($save_con['cache']);	
		$save_con['order_percent'] = intval($save_con['order_percent']);		
		$save_con['redirect'] = intval($save_con['redirect']);		
		
		$category = $save_con['category'];
		
		if( !is_array($category) ) $category = array ();
		
		if( !count($category) ) $category[] = '0';

		$category_list = array();

		foreach ( $category as $value ) {
			$category_list[] = intval($value);
		}
		
		$save_con['category'] = $db->safesql( implode( ',', $category_list ) );
	
		$params = array();
		$find = array();
		$replace = array();
		
		$find[] = "'\r'";
		$replace[] = "";
		$find[] = "'\n'";
		$replace[] = "";
		$save_con = $save_con + $emoticon_config;
		
		$handler = fopen( ENGINE_DIR . '/data/emoticon_config.php', "w" );
		fwrite( $handler, "<?PHP \n\n\$emoticon_config = array (\n\n" );
		foreach ( $save_con as $name => $value ) {
			
			$value = preg_replace( $find, $replace, $value );
			$value = str_replace( "$", "&#036;", $value );
			$value = str_replace( "{", "&#123;", $value );
			$value = str_replace( "}", "&#125;", $value );
			$value = str_replace( chr(0), "", $value );
			$value = str_replace( chr(92), "", $value );
			$value = str_ireplace( "decode", "dec&#111;de", $value );
			
			$name = preg_replace( $find, $replace, $name );
			$name = str_replace( "$", "&#036;", $name );
			$name = str_replace( "{", "&#123;", $name );
			$name = str_replace( "}", "&#125;", $name );
			$name = str_replace( chr(0), "", $name );
			$name = str_replace( chr(92), "", $name );
			$name = str_replace( '(', "", $name );
			$name = str_replace( ')', "", $name );
			$name = str_ireplace( "decode", "dec&#111;de", $name );
			
			fwrite( $handler, "'{$name}' => '{$value}',\n\n" );

		}
		fwrite( $handler, ");\n\n?>" );
		fclose( $handler );
		
		if (function_exists('opcache_reset')) {
			opcache_reset();
		}
		
		msg( "info", $lang['opt_sysok'], $lang['opt_sysok_1'], "?mod=emoticon" );
	
	} else {	
	
	echoheader( "Общие настройки", "Настройка параметров скрипта" );
	
	$emoticon_config['voted_num'] = $emoticon_config['voted_num'] ? $emoticon_config['voted_num'] : 0;
	$emoticon_config['limit_voted'] = $emoticon_config['limit_voted'] ? $emoticon_config['limit_voted'] : 0;
	$emoticon_config['percent_voted'] = $emoticon_config['percent_voted'] ? $emoticon_config['percent_voted'] : 0;
	$emoticon_config['combination_count'] = $emoticon_config['combination_count'] ? $emoticon_config['combination_count'] : 3;
	echo <<<HTML
<style>
.chosen-drop, .chosen-drop ul {
	
	height:200px !important;
	
}

.chosen-container {
	display: block;
}

</style>	
<form action="" method="post">
<input type="hidden" name="user_hash" value="{$dle_login_hash}" />
<input type="hidden" name="mod" value="emoticon">
<input type="hidden" name="action" value="settings">
<input type="hidden" name="is" value="save">
<div class="navbar navbar-default navbar-component navbar-xs" style="z-index: inherit;">
  <div class="navbar-collapse collapse" id="navbar-filter">
    <ul class="nav navbar-nav">
      <li{$menu_active_settings}><a href="?mod=emoticon">{$lang['skin_option']}</a></li>
      <li{$menu_active_list}><a href="?mod=emoticon&action=list">Подборки</a></li>
    </ul>
  </div>
</div>

<div id="general" class="panel panel-flat">
  <div class="table-responsive">

    <table class="table table-normal">
HTML;

	showRow( "Настройка минимального порога", "Минимальное количество голосов определяет сколько голосов за категорию должно быть, чтобы новость была допущена для расмотрения следующего параметра который определяет сколько минимально в процентах категория должна быть для участия в поиске.", "<div style=\"width:100%;max-width:200px;float:right;\"><div style=\"margin-bottom:10px\"><label for=\"voted_num\" style=\"line-height: 22px;\">Минимум голосов:</label> <input id=\"voted_num\" autocomplete=\"off\" class=\"form-control\" type=\"number\" name=\"save_con[voted_num]\" value=\"" . $emoticon_config['voted_num'] . "\" style=\"width:100%;max-width:50px;text-align:center;float: right;\"></div><div><label for=\"percent_voted\" style=\"line-height: 22px;\">Процент:</label> <input id=\"percent_voted\" autocomplete=\"off\" class=\"form-control\" type=\"number\" name=\"save_con[percent_voted]\" value=\"" . $emoticon_config['percent_voted'] . "\" style=\"width:100%;max-width:50px;text-align:center;float: right;\"></div></div>" );
	showRow( "Режим \"Выбиреай с умом\"", "Если установлено то возможность в выборе будет ограничена для каждой новости.<br/>0 - отключает ограничение.", "<input autocomplete=\"off\" class=\"form-control\" type=\"number\" name=\"save_con[limit_voted]\" value=\"" . $emoticon_config['limit_voted'] . "\" style=\"width:100%;max-width:100px;float:right;text-align:center\">" );
	showRow( "Количество новостей в разделе", "По умолчанию использует количество новостей системной настройки<br/>Значение: \"{$config['news_number']}\"", "<input autocomplete=\"off\" class=\"form-control\" type=\"number\" name=\"save_con[news_number]\" value=\"" . ( $emoticon_config['news_number'] ? $emoticon_config['news_number'] : $config['news_number']). "\" style=\"width:100%;max-width:100px;float:right;text-align:center\">" );
	showRow( "Количество подборок для комбинирования", "По умолчанию: 3", "<input autocomplete=\"off\" class=\"form-control\" type=\"number\" name=\"save_con[combination_count]\" value=\"" . $emoticon_config['combination_count'] . "\" style=\"width:100%;max-width:100px;float:right;text-align:center\">" );
	showRow( "Делать редирект на последние {$emoticon_config['combination_count']} выборки ?", "Если отключить то будет показана стандартная ошибка.", "<div style=\"float:right\">" . makeCheckBox( "save_con[redirect]", "{$emoticon_config['redirect']}" ) . "</div>" );
	showRow( "В каких категориях показывать ?", "Используется для выборки категорий и будет ли показано голосование<br/>в полной новости.", "<select data-placeholder=\"{$lang['addnews_cat_sel']}\" title=\"{$lang['addnews_cat_sel']}\" name=\"save_con[category][]\" id=\"categoryselect\" style=\"width:100%;max-width:350px;\" multiple>{$category_select}</select>" );
	showRow( "Разделитель модуля speedbar", "По умолчанию использует системную настройку<br/>Значение: \"{$config['speedbar_separator']}\"", "<input autocomplete=\"off\" class=\"form-control\" type=\"text\" name=\"save_con[speedbar_separator]\" value=\"" . ( $emoticon_config['speedbar_separator'] ? $emoticon_config['speedbar_separator'] : $config['speedbar_separator']). "\" style=\"width:100%;max-width:100px;float:right;text-align:center\">" );
	showRow( "Название модуля в speedbar", "", "<input autocomplete=\"off\" class=\"form-control\" type=\"text\" name=\"save_con[speedbar_title]\" value=\"" . ( $emoticon_config['speedbar_title'] ? $emoticon_config['speedbar_title'] : "Подборки"). "\" style=\"width:100%;max-width:200px;float:right\">" );
	showRow( "Кэширование", "", "<div style=\"float:right\">" . makeCheckBox( "save_con[cache]", "{$emoticon_config['cache']}" ) . "</div>" );
	showRow( "Изменять порядок отоброжения по количеству голосов ?", "Если включено то в полной новости в списке первыми<br/>будут списки с наибольшим количеством процентного соотношения.", "<div style=\"float:right\">" . makeCheckBox( "save_con[order_percent]", "{$emoticon_config['order_percent']}" ) . "</div>" );
	showRow( "Шаблон новостей", "Использовать отдельный шаблон для вывода новостей.<br/> По умолчанию: shortstory.tpl", "<input autocomplete=\"off\" class=\"form-control\" type=\"text\" name=\"save_con[template_news]\" value=\"" . ( $emoticon_config['template_news'] ? $emoticon_config['template_news'] : 'shortstory.tpl'). "\" style=\"width:100%;max-width:200px;float:right;text-align:center\">" );
	showRow( "Шаблон ошибок и уведомлений", "По умолчанию: info.tpl", "<input autocomplete=\"off\" class=\"form-control\" type=\"text\" name=\"save_con[info_template]\" value=\"" . ( $emoticon_config['info_template'] ? $emoticon_config['info_template'] : 'info.tpl'). "\" style=\"width:100%;max-width:200px;float:right;text-align:center\">" );
	
    echo <<<HTML
	</table>
	</div>
</div>
HTML;


	echo "<center><button type=\"submit\" class=\"btn bg-teal btn-raised position-left legitRipple\"><i class=\"fa fa-floppy-o position-left\"></i>Сохранить</button></center></form>";

    echo <<<HTML
	<script type="text/javascript">
	$(function(){
		$('#categoryselect').chosen({allow_single_deselect:true, no_results_text: '{$lang['addnews_cat_fault']}'});
	});
	</script> 
HTML;

	echofooter();
	
	}
	
} else if( $action == "list" ) {
	
	if( $_REQUEST['is'] == "delete" ) {

		if( $_REQUEST['user_hash'] == "" or $_REQUEST['user_hash'] != $dle_login_hash ) {
			
			die('sess_error');
		
		}
		
		$id = intval($_POST['id']);
		
		if( !$id ) die('error');
		
		$row = $db->super_query( "SELECT name, icon FROM " . PREFIX . "_emoticon_list WHERE id = '{$id}'");
		
		if( $row ) {
			
			if( preg_match('#jpg|jpeg|png#is', $row['icon']) ) @unlink( ROOT_DIR . "/uploads/emoticon/" . totranslit($row['icon']) );	
			
			
			$db->query( "DELETE FROM " . PREFIX . "_post_emoticon WHERE emoticon_id = '{$id}'" );
			$db->query( "DELETE FROM " . PREFIX . "_emoticon_list WHERE id = '{$id}'" );
			@unlink( ENGINE_DIR . '/cache/system/emoticon_list.php' );

			die('ok');
			
		} else die('error');
	
	} elseif( $_REQUEST['is'] == "save" ) {
		
	if( $_REQUEST['user_hash'] == "" or $_REQUEST['user_hash'] != $dle_login_hash ) {
		
		msg( "error", array('javascript:history.go(-1)' => "Добавление новой подборки на сайт", '' => $lang['addnews_error'] ), $lang['sess_error'], "javascript:history.go(-1)" );
	
	}
	
	$name = trim( strip_tags ($_POST['name']) );
	$name = $db->safesql( $name );
	$symbol = trim( strip_tags ($_POST['symbol']) );
	$symbol = $db->safesql( $symbol );	
	
	$category = $_POST['category'];
	if( !is_array($category) ) $category = array ();
	
	if( !count($category) ) $category[] = '0';

	$category_list = array();

	foreach ( $category as $value ) {
		$category_list[] = intval($value);
	}

	$category_list = $db->safesql( implode( ',', $category_list ) );	

	if( !$name ) {
		msg( "error", array('javascript:history.go(-1)' => "Добавление списока", '' => $lang['addnews_error'] ), "Имя является обязательным.", "javascript:history.go(-1)" );
		
	}
	
	$filename = check_filename( getFileName() );

	if( $filename ) {

		if( !is_dir( ROOT_DIR . "/uploads/emoticon/" ) ) {
				
			@mkdir( ROOT_DIR . "/uploads/emoticon/", 0777 );
			@chmod( ROOT_DIR . "/uploads/emoticon/", 0777 );

		}
		
		if( !is_dir( ROOT_DIR . "/uploads/emoticon/" ) ) {

			return "{\"error\":\"".$lang['upload_error_0']." /uploads/emoticon/\"}";
		
		}
		
		if ( !$filename ) {
			
			return "{\"error\":\"". $lang['upload_error_4'] ."\"}";
			
		}

		$filename_arr = explode( ".", $filename );
		$type = end( $filename_arr );

		if ( !$type ) {
			
			return "{\"error\":\"".$lang['upload_error_4'] ."\"}";
			
		}

		$error_code = getErrorCode();

		if ( $error_code ) {
			
			return "{\"error\":\"". $error_code ."\"}";
			
		}
			
		$size = getFileSize();
			
		if ( !$size ) {
			
			return "{\"error\":\"". $lang['upload_error_5'] ."\"}";
			
		}
		
		$uploaded_filename = saveFile(ROOT_DIR . "/uploads/emoticon/", $name . '.' . $type);		
		$icon = $name . '.' . $type;
		
	} else {
		
		$icon = $symbol;
		
		//msg( "error", array('javascript:history.go(-1)' => "Emoticon", '' => $lang['addnews_error'] ), "Иконка не загружена", "javascript:history.go(-1)" );
		
	}

		
	$db->query( "INSERT INTO " . PREFIX . "_emoticon_list (name, icon, category) values ('{$name}', '{$icon}', '{$category_list}')" );

	$id = $db->insert_id();
	
	@unlink( ENGINE_DIR . '/cache/system/emoticon_list.php' );
	msg( "success", "Список добавлен", "Подборка" . " \"" . stripslashes( stripslashes( $name ) ) . "\" " . $lang['addnews_ok_2'], array('?mod=emoticon&action=list' => 'Назад к списку' ) );

	}
	
	$emoticon_list = $db->super_query( "SELECT * FROM " . PREFIX . "_emoticon_list WHERE 1 ORDER BY id ASC", true);
	
	echoheader( "Общие настройки", "Список эмодзи" );

	echo <<<HTML
<style>
.tokenfield.form-control {
	
	max-width: 100%;
    display: block;	
	
}

.tokenfield .token > .close {
	
	top: 35%;
	
}
</style>	
<div class="navbar navbar-default navbar-component navbar-xs" style="z-index: inherit;">
  <div class="navbar-collapse collapse" id="navbar-filter">
    <ul class="nav navbar-nav">
      <li{$menu_active_settings}><a href="?mod=emoticon">Настройки</a></li>
      <li{$menu_active_list}><a href="?mod=emoticon&action=list">Списоки</a></li>
    </ul>
  </div>
</div> 
<div id="general" class="panel panel-flat">
  <div class="panel-heading">{$add_template}</div>
  <div class="table-responsive">

    <table class="table table-normal">
	  <thead>
      <tr>
        <th style="width:48px;text-align:center;">#</th>
        <th style="width:80px;text-align:center;">Иконка</th>
        <th>Название</th>
        <th>Категории</th>
        <th style="width:100px;text-align:center;">Меню</th>
      </tr>
      </thead>
	  <tbody>
HTML;



	foreach( $emoticon_list as $val ) {
				
		$menu_link = <<<HTML
        <div class="btn-group">
          <a href="#" class="dropdown-toggle nocolor" data-toggle="dropdown" aria-expanded="true"><i class="fa fa-bars"></i><span class="caret"></span></a>
          <ul class="dropdown-menu text-left dropdown-menu-right">
            <li><a uid="{$val['id']}" class="dellink" href="#"><i class="fa fa-trash-o position-left text-danger"></i>{$lang['word_ldel']}</a></li>
          </ul>
        </div>
HTML;

		if( $config['allow_alt_url'] ) $url = $config['http_home_url'] . 'emoticon/' . $val['id'] . '/';
		else $url = $config['http_home_url'] . '?do=emoticon&id=' . $val['id'];
		
		$val['category'] = $val['category'] ? $val['category'] : '-';

		if( preg_match('/jpg|jpeg|png/is', $val['icon']) ) $icon = "<img src=\"{$config['http_home_url']}uploads/emoticon/".totranslit($val['icon'])."\" style=\"width: 50px;\"/>";
		else $icon = "<span style=\"width: 50px;font-size: 30px;line-height: 50px;text-align: center;border-radius: 50%;display: block;\">" . $val['icon'] . "</span>";
		
		echo "<tr>
        <td><a href=\"{$url}\" target\"_blank\">{$val['id']}</a></td>
        <td id=\"content_{$val['id']}\">{$icon}</td>
        <td>{$val['name']}</td>
        <td>{$val['category']}</td>
        <td style=\"text-align: center;\">{$menu_link}</td>
        </tr>";

	}

	echo "</tbody></table></div></div>";

	echo <<<HTML
<script>
function checkxf ()	{

		var status = '';

		{$save}

		if(document.addcollections.name.value == ''){

			Growl.error({
				title: '{$lang['p_info']}',
				text: 'Название является обязательным'
			});

			status = 'fail';

		}

		return status;

};
	
  jQuery(function($){
	  
	$('.dellink').click(function(){
		
		name = $('#content_'+$(this).attr('uid')).next().text();
		id = $(this).attr('uid');

	    DLEconfirm( 'Вы уверены, что хотите удалить <b>&laquo;'+name+'&raquo;</b> из подборок ?', '{$lang['p_confirm']}', function () {

		$.post('/{$config['admin_path']}?mod=emoticon&action=list', {id: id, is:'delete', user_hash:'{$dle_login_hash}'}, function(data) {
			
        if(data == 'ok'){
          $('#content_'+ id).parent().remove();
        }
		
		});		

		} );

		return false;
	});
	
  });
</script>  
HTML;
	
	echofooter();
} else if( $action == "add" ) {
	
	echoheader( $lang['media_gallery_settings'], $lang['media_gallery_desc'] );

	echo <<<HTML
<style>
.tokenfield.form-control {
	
	max-width: 100%;
    display: block;	
	
}

.tokenfield .token > .close {
	
	top: 35%;
	
}

.chosen-drop, .chosen-drop ul {
	
	height:200px !important;
	
}
</style>	

<div class="panel panel-default">
  <div class="panel-heading">
    Добавление подборки
  </div>
  <div class="list-bordered">
<form action="" method="post" onsubmit="if(checkxf()=='fail') return false;" id="emoticon" name="addemoticon_list" enctype="multipart/form-data">
<input type="hidden" name="user_hash" value="{$dle_login_hash}" />
<input type="hidden" name="mod" value="emoticon">
<input type="hidden" name="action" value="list">
<input type="hidden" name="is" value="save"> 
<div class="" id="addCollections">
    <div class="modal-body">
    <div class="form-group">
      <div class="row">
        <div>
			<label>Название</label>
			<input name="name" id="name" type="text" class="form-control" maxlength="190" autocomplete="off">
        </div>
		<div style="margin-top: 10px;">
			<label>Иконка</label>
			<input type="file" id="icon" name="qqfile" accept=".jpg, .jpeg, .png">
        </div>
		<div style="margin-top: 10px;">
			<label>Символ</label>
			<input type="text" id="symbol" name="symbol" class="form-control" autocomplete="off">
        </div>		
		<div style="margin-top: 10px;">
			<label>Категория</label>
			<select name="category[]" multiple placeholder="Select Some Options">{$category}</select>
        </div>
      </div>
    </div>
      </div>
      <div class="modal-footer" style="margin-top:-20px;">
      <button type="submit" class="btn bg-teal btn-sm btn-raised position-left"><i class="fa fa-floppy-o position-left"></i>{$lang['user_save']}</button>
      <a href="javascript:history.go(-1)" class="btn bg-slate-600 btn-sm btn-raised">{$lang['p_cancel']}</a>
      </div>
</div></form>
  </div>
</div>
HTML;

	echo <<<HTML
<script>
function checkxf ()	{

		var status = '';

		{$save}

		if(document.addemoticon_list.name.value == ''){

			Growl.error({
				title: '{$lang['p_info']}',
				text: 'Название является обязательным'
			});

			status = 'fail';

		}

		return status;

};
	
  jQuery(function($){
	  
	$('select[multiple]').chosen({allow_single_deselect:true, no_results_text: '{$lang['addnews_cat_fault']}'}); 
	
  });
</script>  
HTML;
	
	echofooter();	
	
}
?>