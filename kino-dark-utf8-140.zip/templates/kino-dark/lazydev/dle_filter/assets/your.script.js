$(document).ready(function(){
	/* Библиотеки
  ========================================================================== */	 
  // Инициализация библиотеки для отложенной загрузки изображений
	let observer = lozad('.lozad', {
		threshold: 0.1
	});
	observer.observe();
	// Инициализация подсказки
	if ($(window).width() > 1220) {// Отображение только на экране разрешение которого более 1220px
		tippy('.typsi', {content: 'Tooltip',theme: 'light', arrow: false});

		if ($('.short-story').hasClass('moviebox')) {     
		  tippy('.js-tooltip--btn', {
				content(reference) {
					const id = reference.getAttribute('data-template');
					const template = document.getElementById(id);
					return template.innerHTML;
				},
			});
		}
	};  
  // Инициализация плагина рейтинг заинтересованности пользователя
  $('.rate-ajax').RateInterest();
});