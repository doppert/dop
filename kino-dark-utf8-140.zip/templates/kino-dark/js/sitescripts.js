/* 
@ Название: ;
@ Версия: ;
@ Система управления сайтом: Data Life Engine 13.x;
@ Автор: webkubikc;
@ Связь с автором: (E-MAIL: webkubikc@gmail.com, Telegram: webkubikc, Skype: webkubikc);
*/


$(document).ready(function(){

	/* Переменные
  ========================================================================== */
  let $window = $(window),
		  $doc = $(document),
		  $body = $('body');

  $body.addClass('js'); 

   /* Здесь Вы можете заменить используемый текст в скриптах
  ========================================================================== */  
  textAtr = ["Добавлено в закладки","Удалено из закладок","Функция 'Закладки' позволяет добавить материал в данный блок при помощи всего одного клика.","Ваш голос учтен, спасибо","Необходима регистрация. Регистрируйтесь, и вы сможете добавлять свои коллекции, оценивать и многое другое!","Коллекция добавлена в закладки","Коллекция удалена из закладок","Вы еще ничего не добавляли в коллекции"];   

  /* Плагины
  ========================================================================== */  
  // Инициализация плагина рейтинг заинтересованности пользователя
  $('.rate-interests').RateInterest();
  // Инициализация плагина плейлистов (ЗАКЛАДКИ)
  $("#favoutites-block--content").LoadPlayList();
  // Инициализация плагина коллекций
  $("#favoutites-block--content").LoadCollection();

	/* Библиотеки
  ========================================================================== */	 
  // Инициализация библиотеки для отложенной загрузки изображений
  let observer = lozad('.lozad', {
      threshold: 0.1,
      loaded: function(el) {
        el.classList.add('lozad-loaded');
      }
  });
  observer.observe();

  /* Функции
  ========================================================================== */  

  // Инициализация подсказки о необходимости регистрации
  $body.on('click', '.need-registr', function() {
    Toastify({
      backgroundColor: "linear-gradient(to right, #727cf5, #727cf5)",
      text: textAtr[4],
      duration: 1500,
      newWindow: true,
      close: true,
      gravity: "top",
      positionRight: true,
      stopOnFocus: true
    }).showToast();
    return false;
  });

  // Инициализация функции вывода комментариев пользователя
  // UsercommentNum();


    // Инициализация подсказки
  if ($window.width() > 1220) {// Отображение только на экране разрешение которого более 1220px
    tippy('.typsi', {content: 'Tooltip',theme: 'light', arrow: false});
  }; 

  if ($window.width() > 1220) {// Отображение только на экране разрешение которого более 1220px
    if ($('.short-story').hasClass('moviebox')) {     
      tippy('.js-tooltip--btn', {
        animateFill: false,
        animation: 'scale',
        interactive: true,
        content(reference) {
          const id = reference.getAttribute('data-template');
          const template = document.getElementById(id);
          return template.innerHTML;
        },
        onShown(instance) {
          $("time.ago").timeago();
        }
      });
    }
  }; 


  // Меняем формат даты на человекопонятные
  (function (factory) {
    if (typeof define === 'function' && define.amd) {
    define(['../../../engine/classes/js/jquery'], factory);
    } else {
    factory(jQuery);
    }
  }(function ($) {
    $.timeago = function(timestamp) {
    if (timestamp instanceof Date) {
      return inWords(timestamp);
    } else if (typeof timestamp === "string") {
      return inWords($.timeago.parse(timestamp));
    } else if (typeof timestamp === "number") {
      return inWords(new Date(timestamp));
    } else {
      return inWords($.timeago.datetime(timestamp));
    }
    };
    let $t = $.timeago;

    $.extend($.timeago, {
    settings: {
      refreshMillis: 60000,
      allowFuture: false,
      localeTitle: false,
      strings: {
      prefixAgo: null,
      prefixFromNow: null,
      suffixAgo: "ago",
      suffixFromNow: "from now",
      seconds: "less than a minute",
      minute: "about a minute",
      minutes: "%d minutes",
      hour: "about an hour",
      hours: "about %d hours",
      day: "a day",
      days: "%d days",
      month: "about a month",
      months: "%d months",
      year: "about a year",
      years: "%d years",
      wordSeparator: " ",
      numbers: []
      }
    },
    inWords: function(distanceMillis) {
      let $l = this.settings.strings;
      let prefix = $l.prefixAgo;
      let suffix = $l.suffixAgo;
      if (this.settings.allowFuture) {
      if (distanceMillis < 0) {
        prefix = $l.prefixFromNow;
        suffix = $l.suffixFromNow;
      }
      }

      let seconds = Math.abs(distanceMillis) / 1000;
      let minutes = seconds / 60;
      let hours = minutes / 60;
      let days = hours / 24;
      let years = days / 365;

      function substitute(stringOrFunction, number) {
      let string = $.isFunction(stringOrFunction) ? stringOrFunction(number, distanceMillis) : stringOrFunction;
      let value = ($l.numbers && $l.numbers[number]) || number;
      return string.replace(/%d/i, value);
      }

      let words = seconds < 45 && substitute($l.seconds, Math.round(seconds)) ||
      seconds < 90 && substitute($l.minute, 1) ||
      minutes < 45 && substitute($l.minutes, Math.round(minutes)) ||
      minutes < 90 && substitute($l.hour, 1) ||
      hours < 24 && substitute($l.hours, Math.round(hours)) ||
      hours < 42 && substitute($l.day, 1) ||
      days < 30 && substitute($l.days, Math.round(days)) ||
      days < 45 && substitute($l.month, 1) ||
      days < 365 && substitute($l.months, Math.round(days / 30)) ||
      years < 1.5 && substitute($l.year, 1) ||
      substitute($l.years, Math.round(years));

      let separator = $l.wordSeparator || "";
      if ($l.wordSeparator === undefined) { separator = " "; }
      return $.trim([prefix, words, suffix].join(separator));
    },
    parse: function(iso8601) {
      let s = $.trim(iso8601);
      s = s.replace(/\.\d+/,""); 
      s = s.replace(/-/,"/").replace(/-/,"/");
      s = s.replace(/T/," ").replace(/Z/," UTC");
      s = s.replace(/([\+\-]\d\d)\:?(\d\d)/," $1$2");
      return new Date(s);
    },
    datetime: function(elem) {
      let iso8601 = $t.isTime(elem) ? $(elem).attr("datetime") : $(elem).attr("title");
      return $t.parse(iso8601);
    },
    isTime: function(elem) {
      return $(elem).get(0).tagName.toLowerCase() === "time";
    }
    });

    let functions = {
    init: function(){
      let refresh_el = $.proxy(refresh, this);
      refresh_el();
      let $s = $t.settings;
      if ($s.refreshMillis > 0) {
      setInterval(refresh_el, $s.refreshMillis);
      }
    },
    update: function(time){
      $(this).data('timeago', { datetime: $t.parse(time) });
      refresh.apply(this);
    }
    };

    $.fn.timeago = function(action, options) {
    let fn = action ? functions[action] : functions.init;
    if(!fn){
      throw new Error("Unknown function name '"+ action +"' for timeago");
    }
    this.each(function(){
      fn.call(this, options);
    });
    return this;
    };

    function refresh() {
    let data = prepareData(this);
    if (!isNaN(data.datetime)) {
      $(this).text(inWords(data.datetime));
    }
    return this;
    }

    function prepareData(element) {
    element = $(element);
    if (!element.data("timeago")) {
      element.data("timeago", { datetime: $t.datetime(element) });
      let text = $.trim(element.text());
      if ($t.settings.localeTitle) {
      element.attr("title", element.data('timeago').datetime.toLocaleString());
      } else if (text.length > 0 && !($t.isTime(element) && element.attr("title"))) {
      element.attr("title", text);
      }
    }
    return element.data("timeago");
    }

    function inWords(date) {
    return $t.inWords(distance(date));
    }

    function distance(date) {
    return (new Date().getTime() - date.getTime());
    }

    document.createElement("abbr");
    document.createElement("time");
  }));

  (function() {
    function numpf(n, f, s, t) {
    let n10 = n % 10;
    if ( (n10 == 1) && ( (n == 1) || (n > 20) ) ) {
      return f;
    } else if ( (n10 > 1) && (n10 < 5) && ( (n > 20) || (n < 10) ) ) {
      return s;
    } else {
      return t;
    }
    }

    jQuery.timeago.settings.strings = {
    prefixAgo: null,
    prefixFromNow: "через",
    suffixAgo: "назад",
    suffixFromNow: null,
    seconds: "меньше минуты",
    minute: "минуту",
    minutes: function(value) { return numpf(value, "%d минута", "%d минуты", "%d минут"); },
    hour: "час",
    hours: function(value) { return numpf(value, "%d час", "%d часа", "%d часов"); },
    day: "день",
    days: function(value) { return numpf(value, "%d день", "%d дня", "%d дней"); },
    month: "месяц",
    months: function(value) { return numpf(value, "%d месяц", "%d месяца", "%d месяцев"); },
    year: "год",
    years: function(value) { return numpf(value, "%d год", "%d года", "%d лет"); }
    };
  })();

  // Меняем формат даты
  $("time.ago").timeago();


  // Шапка: скролл шапки
  let tempScrollTop, currentScrollTop = 0;
  let header = $('#header'), headerPos = header.offset().top, headerHeight = header.outerHeight(), 
  stickyHide = headerPos + 280, headerPosFixed = headerPos + 180; 
  header.wrap('<div class="header-sticky--wrapper" style="height:'+headerHeight+'px"></div>');
  $window.scroll(function(){  
    if ($(this).scrollTop () > headerPos) {
      header.addClass('sticky');
      $body.addClass('search-class');
      $('.search-block').addClass('fixed');
      $('.js-header--search').addClass('active');
    } else {
      header.removeClass('sticky');
      $body.removeClass('search-class');
      $('.search-block').removeClass('fixed');
      $('.js-header--search').removeClass('active');
    };
    if ($(this).scrollTop () > stickyHide) {
      header.addClass('sticky-hide')
      $('.search-block').addClass('fixed-hide');
    } else {
      header.removeClass('sticky-hide')
      $('.search-block').removeClass('fixed-hide');
    };
    currentScrollTop = $window.scrollTop();
    if (tempScrollTop < currentScrollTop ) {
      header.removeClass('sticky-visible')
      $('.search-block').removeClass('fixed-visible');
    } else if (tempScrollTop > currentScrollTop ) {
      header.addClass('sticky-visible')
      $('.search-block').addClass('fixed-visible');
    };
    tempScrollTop = currentScrollTop;
  });

  // Шапка: кнопка вызова поиска
  $body.on("click", ".js-header--search", function(){
    $(".search-block").toggleClass("active");
     $(this).find('i').toggleClass('fa-search fa-times');
     $(this).find('i').toggleClass('is-active');
  });

  // Шапка: меню
  if ($window.width() > 1220) {
    $('.has-dropdown').mouseenter(function(){
      $(this).addClass('menuactive');
      $(".fav-item").addClass("active");
    }).mouseleave(function(event){
      $(this).removeClass('menuactive');
      $(".fav-item").removeClass("active");
    });
  };  

  // Поиск: вызов модального окна
  $body.on("click", ".modal-btn", function(e){
    $(".search-block--popularblock").addClass("active");
    $(".search-popular--item").addClass("active");
    $(".btn-close").addClass("active");
    e.stopPropagation()
  });
  $body.on('click','.js-close',function(){
    $('.search-block--popularblock').removeClass('active');
    $(".search-popular--item").removeClass("active");
    $(".btn-close").removeClass("active");
  });

  // Скрываем блок с подсказкой
  $body.on('click','.js-tooltipclose',function(){
    sessionStorage.setItem('mess', 1);
    $('.tooltip-block').removeClass('active');
  });
  let mess = sessionStorage.getItem('mess');
  if (mess != 1) {
    $('.tooltip-block').addClass('active');
  };

  // Рейтинги
  $('.rate-another').each(function(){
    let a = $(this), b = a.find('.rate-another--text'), c = parseFloat(b.text(), 10), d = c.toFixed(1), f = d*10;
    a.append('<div class="rate-bar"><div class="rate-fill anim" style="width: '+f+'%"></div></div>');
  });
  // Вызов выпадающего меню по клику
  $body.on('click','.js-has--dropdown',function(e){
   $(this).toggleClass('active');
    e.stopPropagation()
  });

  // Вывод рейтинга в минипрофиле
  $(".js-login--rate").each(function() {
    let a = $("#js-login--link").attr("href");
    $.ajax({
      url: a,
      type: "get",
      cache: true,
      success: function(a) {
        $($(a).find("#js-userrate--count")).each(function() {
          let e = $(this).find(".ratingtypeplusminus").text().slice(-1);
            $(".js-login--btn .login-block--rate").append('' + e + '');
            if ( e <= 0) {
              $("body").find('.js-login--btn .login-block--name .name-color').addClass('ratebad');
              $(".js-login--btn .login-block--rate").removeClass('is-success');
              $(".js-login--btn .login-block--rate").addClass('is-danger');
            }else{
              $("body").find('.js-login--btn .login-block--name .name-color').addClass('rategood');
              $(".js-login--btn .login-block--rate").removeClass('is-danger');
              $(".js-login--btn .login-block--rate").addClass('is-success');
            }
        })
      }
    })
  });

  // Трейлер
  $body.on('click', '.trailershow-btn', function() {
    $body.append('<div class="trailer-frame"><div class="iframe" id="trailer-box"></div><div class="overlay"></div><div class="strailer-close"><i class="far fa-times"></i></div></div>');
    let w = $window.width() - 40;
    let meta = $(this).parent('.mm-top').children('.s-link');
    if($('.trailer-frame').width() > w) {
      $('.trailer-frame').height(w / ($('.trailer-frame').width() / $('.trailer-frame').height())).width(w).css({
        'margin-left': 0 - w / 2
      });
    }
    $('.trailer-frame').css('visibility','visible');
    $('.trailer-frame').animate({
      opacity: 1,
      top: $window.height() / 2 - $('.trailer-frame').height() / 2
    }, 'slow', function() {
      metaS = meta.attr('href');
      $.ajax({
        url: metaS,
        beforeSend: function() {
          ShowLoading('');
        },
        success: function(data) {
          $("#trailer-box").append($('#trailer-place', data).html());
          $("#trailer-box").append('<script type="text/javascript" src="/engine/classes/html5player/player.js"></script><link media="screen" href="/engine/classes/html5player/player.css" type="text/css" rel="stylesheet" />');
          HideLoading('');
          // Инициализация библиотеки для отложенной загрузки изображений
          let observer = lozad('.lozad', {
              threshold: 0.1,
              loaded: function(el) {
                el.classList.add('lozad-loaded');
              }
          });
          observer.observe();
        },
        error: function() {
          HideLoading('');
          alert('Что-то пошло не так');
        }
      });
    });
  });
  // Скрыть плеер
  $body.on('click', '.strailer-close, .trailer-frame .overlay', function() {
    $(this).parent().find('iframe').remove();
    $('.trailer-frame').animate({opacity: 0, top: 0}, function() {
      $(this).remove();
    });
    $('.trailer-frame').css('visibility','hidden');
  });

  // AJAX Вывод блока закладок
   $doc.on('click', '.favmod', function(e) {
    e.preventDefault();
    let $this = $(this);
    ShowLoading();
    $("#favoutites-block--content").empty();
    $.ajax({
      url: dle_root + 'engine/mods/favorites/ajax.php',
      type: 'POST',
      dataType: 'json',
      cache: true,
      data: {
        newsid: $this.data('id')
      },
    }).done(function() {
      $this.toggleClass('active');
      if($this.hasClass('active')) {
        Toastify({
          backgroundColor: "#242831",
          text: textAtr[0],
          duration: 1500,
          newWindow: true,
          close: true,
          gravity: "top",
          positionRight: true,
          stopOnFocus: true
        }).showToast();
      } else {
        Toastify({
          backgroundColor: "#242831",
          text: textAtr[1],
          duration: 1500,
          newWindow: true,
          close: true,
          gravity: "top",
          positionRight: true,
          stopOnFocus: true
        }).showToast();
      };
    }).fail(function(error) {
      DLEalert(error.responseText, dle_info);
    }).always(function() {
      HideLoading();
      let a = $("#js-playlist--link").attr("href");
      $("#js-playlist--link").show();
      $.ajax({
        url: a,
        type: "get",
        cache: true,
        success: function(a) {
          $($(a).find(".short-story")).each(function() {
            let a = $(this).find(".moviebox-header--link").attr("href"),
              e = $(this).find(".mt-title").text(),
              g = $(this).find(".mt-category").text(),
              p = $(this).find(".moviebox-type").text(),
              l = $(this).find(".poster-figure img").data("src");
          $(".favoutites-block--content").append('<article class="fav-item moviebox position-relative mb-2 animation-3s bbp"><a href="' + a + '" title="' + e + '" class="animation-3s d-flex flex-row-reverse"><header class="moviebox-header animation-1s w100 p-2 flex-fx"><h2 class="moviebox-title mb-0 txt-bold--700 txt-small txt-uppercase txt-ellipsis">' + e + '</h2><div class="moviebox-genres txtcolor-gray txt-smaller mb-2 txt-ellipsis">' + g + '</div><div class="moviebox-header--meta txt-small txtcolor-gray d-flex justify-content-between align-content-center"></div></header><div class="moviebox-poster"><figure class="poster-figure poster-img poster-img--responsive is-5 animation-3s"><img src="data:image/gif;base64,R0lGODlhAQABAIAAAMPDwwAAACwAAAAAAQABAAACAkwBADs=" data-src="' + l + '" alt="' + e + '" class="img-fit lozad" width="52" height="73"></figure></div></a></article>');
          })
        },
        complete: function(a) {
          // Инициализация библиотеки для отложенной загрузки изображений
          let observer = lozad('.lozad', {
             threshold: 0.1,
              loaded: function(el) {
                el.classList.add('lozad-loaded');
              }
          });
          observer.observe();
          // Подсчет елементов в плейлисте
          $(".playlist-count").each(function() {
            let length = $('.favoutites-block--content .fav-item.moviebox').length;
            $(this).html(length);
          });
          // Если елементов нет в плейлисте, выводить текст.
          if (!$(".favoutites-block--content").has(".fav-item").length) {
            $(".favoutites-dropdown").removeClass("position-fixed");
            $(".favoutites-dropdown").addClass("position-absolute");
            $("#js-playlist--link").hide();
            $(".favoutites-block--content").append('<div class="playlist-block--title p-1 u_txtcolor-gray u_small d-flex align-items-center txtcolor-gray"><i class="far fa-info-circle mr-3 txt-bigger"></i> <span>'+textAtr[2]+'</span></div>')
          };
        }
      });
    });
  });

  //Выводим первую букву логина, если нет аватара.
  $('.js-author').each(function(){
    let a = $(this), b = a.closest('.js-comment'), c = a.text().substr(0,1), 
        f = b.find('.js-avatar'), e = f.children('img').attr('src'),
    d = ["#c57c3b","#753bc5","#79c53b","#eb3b5a","#45aaf2","#2bcbba","#778ca3"], rand = Math.floor(Math.random() * d.length);
    if (e == '/templates/'+dle_skin+'/dleimages/noavatar.png') {
      f.html('<div class="comment-letter avatar size-1 rounded-circle d-flex justify-content-center align-items-center txt-uppercase txtcolor-light" style="background-color:'+d[rand]+'">'+c+'</div>');
    };
  }); 

  // Скрываем блок с подсказкой
  $body.on('click','.collections_fav-add',function(){
    Toastify({
      backgroundColor: "#242831",
      text: textAtr[5],
      duration: 1500,
      newWindow: true,
      close: true,
      gravity: "top",
      positionRight: true,
      stopOnFocus: true
    }).showToast();
  });
  $body.on('click','.collections_fav-remove',function(){
    Toastify({
      backgroundColor: "#242831",
      text: textAtr[6],
      duration: 1500,
      newWindow: true,
      close: true,
      gravity: "top",
      positionRight: true,
      stopOnFocus: true
    }).showToast();
  });


  // Рейтинг комментариев
  $(".comments-block--rate").each(function() {
    let a = $(this), 
    c = parseInt(a.find('.ratingtypeplusminus').text());
    if ( c <= 0 ) {
      a.removeClass('is-success');
      a.addClass('is-danger');
    } else if (c > 0) {
     a.removeClass('is-danger');
     a.addClass('is-success');
    };
  });

  // Показать скрытый комментарий
  $body.on('click','.js-hopen-comment',function(e){
   $('.negative-comments').addClass('negative-none');
   $('.comment-none').addClass('is-active');
  });

  // Показать/скрыть настройки профиля
  $body.on('click','.js-openclose--options',function(e){
   $(".js-options").toggleClass('is-active');
  });

  // Замена checkbox
  $('input[type="checkbox"]').each(function(i) {
    let my = $(this),
    name = my.attr('id'),
    label;
    if( !name ) {
      my.attr({'id': 'checkbox_'+i});
      name = my.attr('id');
    }
    label = $('label[for="'+name+'"]');
    if( !label.length ) {
      if( my.parent('label').length ) label = my.parent('label').attr({'for': name});
      else {
        my.after('<label for="'+name+'"></label>');
        label = $('label[for="'+name+'"]');
      }
    }
    if( label.length ) {
      my.remove();
      let svg;
      if( label.data('icon') == 'icon-close' ) svg = '<svg class="icon icon-close" viewbox="0 0 220.176 220.176"><path d="M131.577,110.084l84.176-84.146c5.897-5.928,5.897-15.565,0-21.492 c-5.928-5.928-15.595-5.928-21.492,0l-84.176,84.146L25.938,4.446c-5.928-5.928-15.565-5.928-21.492,0s-5.928,15.565,0,21.492 l84.146,84.146L4.446,194.26c-5.928,5.897-5.928,15.565,0,21.492c5.928,5.897,15.565,5.897,21.492,0l84.146-84.176l84.176,84.176 c5.897,5.897,15.565,5.897,21.492,0c5.897-5.928,5.897-15.595,0-21.492L131.577,110.084z"></path></svg>';
      else if( my.attr('checked') ) svg = '<svg class="icon icon-checkbox-checked" viewBox="0 0 19.58 19.58"><path d="M5.54,7.93,4,9.46l4.89,4.89L19.79,3.47,18.27,2,8.91,11.31Zm12.08,9.69H2.39V2.39H13.27V.21H2.39A2.18,2.18,0,0,0,.21,2.39V17.62a2.18,2.18,0,0,0,2.18,2.17H17.62a2.18,2.18,0,0,0,2.17-2.17V8.91H17.62Zm0,0" transform="translate(-0.21 -0.21)"></path></svg>';
      else svg = '<svg class="icon icon-checkbox" viewBox="0 0 19.58 19.58"><path d="M17.61.21H2.38A2.18,2.18,0,0,0,.21,2.39h0V17.62a2.18,2.18,0,0,0,2.17,2.17H17.62a2.18,2.18,0,0,0,2.17-2.17V2.39A2.18,2.18,0,0,0,17.61.21Zm0,17.41H2.39V2.39H17.61V13.27h0Z" transform="translate(-0.21 -0.21)"></path></svg>';
      if( my.attr('checked') ) label.addClass('checked');
      label.html(label.html().trim());
      my.prependTo(label.addClass('checkbox').prepend(svg));
    }
  });
  
  $('form').on('reset', function() {
    $(this).find('input').each(function() {
      if( $(this).attr('type') == 'checkbox' ) $(this).prop('checked', false).removeAttr('checked');
      else if( $(this).attr('name') == 'story' ) $(this).removeAttr('value');
    });
    $(this).find('select').each(function() {
      $(this).find('option').removeAttr('selected');
      $(this).find('option').eq(0).prop('selected', true);
      $(this).trigger('change');
    });
    $(this).find('label.checkbox').each(function() {
      $(this).removeClass('checked');
      let icon = $(this).parent().children('.icon');
      if( !$(this).data('icon') ) {
        if( icon.hasClass('icon-checkbox-checked') ) icon.replaceWith('<svg class="icon icon-checkbox" viewBox="0 0 19.58 19.58"><path d="M17.61.21H2.38A2.18,2.18,0,0,0,.21,2.39h0V17.62a2.18,2.18,0,0,0,2.17,2.17H17.62a2.18,2.18,0,0,0,2.17-2.17V2.39A2.18,2.18,0,0,0,17.61.21Zm0,17.41H2.39V2.39H17.61V13.27h0Z" transform="translate(-0.21 -0.21)"></path></svg>');
      }
    });
  });

  $body.on('change', 'label.checkbox input', function() {
    let icon = $(this).parent().children('.icon');
    $(this).parent().toggleClass('checked');
    if( !$(this).parent().data('icon') ) {
      if( icon.hasClass('icon-checkbox-checked') ) icon.replaceWith('<svg class="icon icon-checkbox" viewBox="0 0 19.58 19.58"><path d="M17.61.21H2.38A2.18,2.18,0,0,0,.21,2.39h0V17.62a2.18,2.18,0,0,0,2.17,2.17H17.62a2.18,2.18,0,0,0,2.17-2.17V2.39A2.18,2.18,0,0,0,17.61.21Zm0,17.41H2.39V2.39H17.61V13.27h0Z" transform="translate(-0.21 -0.21)"></path></svg>');
      else icon.replaceWith('<svg class="icon icon-checkbox-checked" viewBox="0 0 19.58 19.58"><path d="M5.54,7.93,4,9.46l4.89,4.89L19.79,3.47,18.27,2,8.91,11.31Zm12.08,9.69H2.39V2.39H13.27V.21H2.39A2.18,2.18,0,0,0,.21,2.39V17.62a2.18,2.18,0,0,0,2.18,2.17H17.62a2.18,2.18,0,0,0,2.17-2.17V8.91H17.62Zm0,0" transform="translate(-0.21 -0.21)"></path></svg>');
    }    
  });

  if ($window.width() < 1280) {// Отображение только на экране разрешение которого менее 1280px
    // Показать/скрыть второе меню в шапке
    $body.on('click','.js-header--smenu',function(e){
     $('.header-navigation--colpostition').toggleClass('is-active');
     $(this).find('i').toggleClass('fa-ellipsis-v fa-times');
     $(this).find('i').toggleClass('is-active');
    });
    // Показать/скрыть выезжающая панель с меню
    $body.on('click','.js-close',function(){
      $('#aside-sidebar, .sbtn-close').removeClass('is-active');
      $body.removeClass('opened-menu');
      $('.overlay-box').fadeOut(200);
    });
    $body.append('<div class="overlay-box js-close"></div><aside class="aside-sidebar" id="aside-sidebar"></aside><div class="sbtn-close js-close"><span class="far fa-times"></span></div>');
    $('.to-mobile').each(function() {
      $(this).clone().prependTo('#aside-sidebar');
    });
    $("#js-header--menubtn").click(function(){
      $('.overlay-box').fadeIn(200);
      $('#aside-sidebar, .sbtn-close').addClass('is-active');
      $body.addClass('opened-menu');
    });
    $body.on('click','.header-menu--item.has-dropdown',function(){
      $(this).toggleClass('is-active');
      $(this).children('.dropdown-menu').toggleClass('is-active');
    });
    $body.on('click','.header-menubtn',function(){
      $(this).toggleClass('is-active');
      $(this).children('.dropdown-menu').toggleClass('is-active');
    });
    $body.on('click','.js-login--btn',function(){
      $('.login-block').toggleClass('is-active');
      $(".login-block").find('.dropdown-menu').toggleClass('is-active');
    });
  }
    
});


// Для занесения в локальную память последнего времени редактирования и проверять были ли изменение после
$(document).ready(function() {
    timeEdit = $(".notice-list .notice-item:first" ).attr( "id");
    $(".notice-alarm" ).hover( function(){
        localStorage.setItem("timeEdit", timeEdit );
    });
    if (localStorage.getItem('timeEdit') == timeEdit) {
        let localValue = localStorage.getItem('bricks');
    } 
    // для подсчета изменений, если нужно
    $(function(){
        $('.notice-list .notice-item').each(function(){
            timEdg = $(this).attr( "id");
            if (timEdg > localStorage.getItem('timeEdit') ) {
                $(this).addClass("newlist");
            }
            $(".notice-count").html($(".notice-list .notice-item.newlist").length);
        })
    });
});


/* Плагины
  ========================================================================== */ 
// Плагины: рейтинг заинтересованности пользователя
jQuery.fn.RateInterest = function(){
  return this.each(function() {
    let a = $(this);
    let b = parseInt(a.find('.ratehide').text(),10);
    let c = parseInt(a.find('span[id*=vote]').text(),10);
        if ( c >= b && c > 0 ) {
        let t = Math.round((c - (c - b)/2)/c*100);
        a.append('<div class="rate-textnum txt-small d-flex align-items-center txt-bold--700"> '+t+'%</div>');
        a.append('<div class="rate-bar"><div class="rate-fill anim" style="width: '+t+'%"></div></div>');
        } else {
          a.append('<div class="rate-textnum txt-small d-flex align-items-center txt-bold--700"> 0%</div>');
          a.append('<div class="rate-bar"><div class="rate-fill anim" style="width: 0%"></div></div>');
        };
  });
}; 

// Плейлисты (ЗАКЛАДКИ)  
jQuery.fn.LoadPlayList = function() {
  return this.each(function() {
    $(".favoutites-block--content").empty();
    let a = $("#js-playlist--link").attr("href");
    $("#js-playlist--link").show();
    $.ajax({
      url: a,
      type: "get",
      cache: true,
      success: function(a) {
        $($(a).find(".short-story")).each(function() {
          let a = $(this).find(".moviebox-header--link").attr("href"),
            e = $(this).find(".mt-title").text(),
            g = $(this).find(".mt-category").text(),
            p = $(this).find(".moviebox-type").text(),
            l = $(this).find(".poster-figure img").data("src");
          $(".favoutites-block--content").append('<article class="fav-item moviebox position-relative mb-2 animation-3s bbp"><a href="' + a + '" title="' + e + '" class="animation-3s d-flex flex-row-reverse"><header class="moviebox-header animation-1s w100 p-2 flex-fx"><h2 class="moviebox-title mb-0 txt-bold--700 txt-small txt-uppercase txt-ellipsis">' + e + '</h2><div class="moviebox-genres txtcolor-gray txt-smaller mb-2 txt-ellipsis">' + g + '</div><div class="moviebox-header--meta txt-small txtcolor-gray d-flex justify-content-between align-content-center"></div></header><div class="moviebox-poster"><figure class="poster-figure poster-img poster-img--responsive is-5 animation-3s"><img src="data:image/gif;base64,R0lGODlhAQABAIAAAMPDwwAAACwAAAAAAQABAAACAkwBADs=" data-src="' + l + '" alt="' + e + '" class="img-fit lozad" width="52" height="73"></figure></div></a></article>');
        })
      },
      complete: function(a) {
        // Инициализация библиотеки для отложенной загрузки изображений
        let observer = lozad('.lozad', {
           threshold: 0.1,
            loaded: function(el) {
              el.classList.add('lozad-loaded');
            }
        });
        observer.observe();
        // Подсчет елементов в плейлисте
        $(".playlist-count").each(function() {
          let length = $('.favoutites-block--content .fav-item.moviebox').length;
          $(this).html(length);
        });
        // Если елементов нет в плейлисте, выводить текст.
        if (!$(".favoutites-block--content").has(".fav-item").length) {
          $("#js-playlist--link").hide();
          $(".favoutites-block--content").append('<div class="playlist-block--title p-1 u_txtcolor-gray u_small d-flex align-items-center txtcolor-gray"><i class="far fa-info-circle mr-3 txt-bigger"></i> <span>'+textAtr[2]+'</span></div>')
        };
      }
    });
  });
} 

// Коллекции 
jQuery.fn.LoadCollection = function() {
  return this.each(function() {
    $(".collection-block--content").empty();
    let a = $("#js-collection--link").attr("href");
    $("#js-collection--link").show();
    $.ajax({
      url: a,
      type: "get",
      cache: true,
      success: function(a) {
        $($(a).find(".collection-item")).each(function() {
          let a = $(this).find(".collection-item--link").attr("href"),
            e = $(this).find(".moviebox-title").text(),
            g = $(this).find(".badge").text(),
            l = $(this).find(".img-fit").data("src");
          $(".collection-block--content").append('<article class="collection-item moviebox position-relative mb-4 animation-3s"><header class="moviebox-header position-absolute animation-1s p-2 col"><a href="'+ a +'" title="'+ e +'" class="collection-item--link d-block position-relative"><div class="moviebox-title--text mb-2 font-family--JS txtcenter txt-small txt-uppercase">Коллекция:</div><h2 class="moviebox-title mb-0 txtcolor-light font-family--JS txt-bold--700 txt-small txt-uppercase">'+ e +'</h2></a></header><div class="moviebox-poster"><figure class="poster-figure poster-img poster-img--responsive is-1 animation-3s"><img src="data:image/gif;base64,R0lGODlhAQABAIAAAMPDwwAAACwAAAAAAQABAAACAkwBADs=" data-src="'+ l +'" alt="'+ e +'" class="img-fit lozad" width="349" height="84"></figure><div class="badges bad-right d-flex flex-column typsi"><div class="badge is-dark txt-bold--500">'+ g +'</div></div></div></article>');
        })
      },
      complete: function(a) {
        // Инициализация библиотеки для отложенной загрузки изображений
        let observer = lozad('.lozad', {
            threshold: 0.1,
            loaded: function(el) {
              el.classList.add('lozad-loaded');
            }
        });
        observer.observe();
        // Подсчет елементов в плейлисте
        $(".collection-count").each(function() {
          let length = $('.collection-block--content .collection-item.moviebox').length;
          $(this).html(length);
        });
        // Если елементов нет в плейлисте, выводить текст.
        if (!$(".collection-block--content").has(".collection-item").length) {
          $("#js-collection--link").hide();
          $(".collection-block--content").append('<div class="collection-block--title p-1 u_txtcolor-gray u_small d-flex align-items-center txtcolor-gray"><i class="far fa-info-circle mr-3 txt-bigger"></i> <span>'+textAtr[7]+'</span></div>')
        };
      }
    });
  });
} 

/* Функции
  ========================================================================== */  

// Функции: рейтинг статей
function doRate( rate, id ) {
  ShowLoading('');

  $.get(dle_root + "engine/ajax/controller.php?mod=rating", { go_rate: rate, news_id: id, skin: dle_skin, user_hash: dle_login_hash }, function(data){

    HideLoading('');

    if ( data.success ) {
      let rating = data.rating;

      rating = rating.replace(/&lt;/g, "<");
      rating = rating.replace(/&gt;/g, ">");
      rating = rating.replace(/&amp;/g, "&");

      $("#ratig-layer-" + id).html(rating);
      $("#vote-num-id-" + id).html(data.votenum);
      $("#likes-id-" + id).html(data.likes);
      $("#dislikes-id-" + id).html(data.dislikes);
      Toastify({
      backgroundColor: "#242831",
      text: textAtr[3],
      duration: 3000
      }).showToast();

    } else if (data.error) {
      Toastify({
      backgroundColor: "#242831",  
      text: data.errorinfo, dle_info,
      duration: 3000
      }).showToast();
    }
  }, "json");
};


// Функции: голосовой поиск
function startDictation() {
  if($('#story').val().length>3) $('#story').change();
   if (window.hasOwnProperty('webkitSpeechRecognition')) {
    let recognition = new webkitSpeechRecognition();
    let story = document.getElementById('story');
    recognition.continuous = false;
    recognition.interimResults = true;
    recognition.lang = "ru-RU";
    recognition.start();
    recognition.onresult = function(e) {
      story.value = e.results[0][0].transcript;
      story.dispatchEvent(new Event('input', { bubbles: true }));
      let a = $('#story').val();
      0 == a.length ? $("#searchsuggestions").fadeOut() : dle_search_value != a && a.length >= dle_min_search && (clearInterval(dle_search_delay), dle_search_delay = setInterval(function() {
        dle_do_search(a)
      }, 600))
    };
  }
}




